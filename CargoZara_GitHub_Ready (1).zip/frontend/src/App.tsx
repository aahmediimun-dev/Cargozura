import React, { useState, useEffect } from 'react';

// Types matching Backend Schemas
interface Order {
  id: string;
  customer_name: string;
  latitude: number;
  longitude: number;
  demand_weight: number;
  package_volume: number;
  delivery_type: string;
  time_window_start: string;
  time_window_end: string;
  service_time: number;
  priority: string;
  fragile: boolean;
  stackable: boolean;
  status: string; // 'pickup' | 'in_transit' | 'delivered'
}

interface Vehicle {
  id: string;
  vehicle_type: string;
  max_weight_capacity: number;
  length: number;
  width: number;
  height: number;
  volume_capacity: number;
  fuel_type: string;
  cost_per_km: number;
  availability: boolean;
  current_location: string;
  driver_assigned?: string;
  status: string;
}

interface Driver {
  id: string;
  name: string;
  availability: boolean;
  shift_start: string;
  shift_end: string;
  license_type: string;
  vehicle_compatibility: string;
  max_working_hours: number;
  current_assignment?: string;
  status: string;
}

interface PackageItem {
  id: string;
  name: string;
  type: string;
  length: number;
  width: number;
  height: number;
  weight: number;
  qty: number;
  color: string;
  fragile: boolean;
}

interface ContainerSpec {
  id: string;
  name: string;
  length: number;
  width: number;
  height: number;
  maxWeight: number;
  volume: number;
}

export default function App() {
  // Admin Authentication State
  const [adminToken, setAdminToken] = useState<string | null>(() => localStorage.getItem('logiopt_admin_token'));
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [loginUsername, setLoginUsername] = useState<string>('admin');
  const [loginPassword, setLoginPassword] = useState<string>('');
  const [loginError, setLoginError] = useState<string>('');
  const [loginLoading, setLoginLoading] = useState<boolean>(false);

  // Active Dashboard Tab
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [apiStatus, setApiStatus] = useState<'connected' | 'checking' | 'error'>('checking');
  
  // Data States
  const [orders, setOrders] = useState<Order[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [analytics, setAnalytics] = useState<any>(null);

  // Selected Order for Tracking
  const [trackedOrderId, setTrackedOrderId] = useState<string>('ORD-101');
  
  // Add Order Form
  const [showAddOrder, setShowAddOrder] = useState(false);
  const [newOrder, setNewOrder] = useState<Partial<Order>>({
    id: `ORD-${Math.floor(116 + Math.random() * 800)}`,
    customer_name: '',
    latitude: 17.3850,
    longitude: 78.4867,
    demand_weight: 250,
    package_volume: 1.0,
    delivery_type: 'drop',
    time_window_start: '09:00',
    time_window_end: '17:00',
    service_time: 15,
    priority: 'normal',
    fragile: false,
    stackable: true,
    status: 'pickup'
  });

  // VRPTW Optimization State
  const [optimizing, setOptimizing] = useState(false);
  const [optResult, setOptResult] = useState<any>(null);
  const [optObjective, setOptObjective] = useState('minimize_distance');

  // 3D Cargo Studio State - Multi-Container & Multi-Package
  const containerTypes: ContainerSpec[] = [
    { id: 'C1', name: '20ft Container Truck (16T)', length: 6.5, width: 2.4, height: 2.5, maxWeight: 7500, volume: 39.0 },
    { id: 'C2', name: '32ft Multi-Axle Freight (24T)', length: 9.2, width: 2.6, height: 2.8, maxWeight: 14000, volume: 67.0 },
    { id: 'C3', name: 'Eicher Medium Truck (8T)', length: 5.2, width: 2.2, height: 2.2, maxWeight: 4200, volume: 25.1 },
    { id: 'C4', name: 'Electric Delivery Van (EV)', length: 3.8, width: 1.9, height: 1.9, maxWeight: 1800, volume: 13.7 }
  ];
  const [selectedContainer, setSelectedContainer] = useState<ContainerSpec>(containerTypes[0]);

  const [cargoPackages, setCargoPackages] = useState<PackageItem[]>([
    { id: 'PKG-1', name: 'Electronics Master Cartons', type: 'Electronics', length: 1.2, width: 0.8, height: 0.8, weight: 120, qty: 8, color: 'bg-blue-500/80 border-blue-400 text-white', fragile: true },
    { id: 'PKG-2', name: 'Deccan Agro Cotton Bales', type: 'Textile', length: 1.4, width: 1.0, height: 1.0, weight: 280, qty: 5, color: 'bg-amber-500/80 border-amber-400 text-white', fragile: false },
    { id: 'PKG-3', name: 'Vizag Pharma Temp-Safe Crate', type: 'Pharma', length: 0.9, width: 0.7, height: 0.7, weight: 85, qty: 6, color: 'bg-emerald-500/80 border-emerald-400 text-white', fragile: true },
    { id: 'PKG-4', name: 'Heavy Industrial Fasteners', type: 'Industrial', length: 1.5, width: 1.1, height: 1.0, weight: 350, qty: 4, color: 'bg-purple-500/80 border-purple-400 text-white', fragile: false }
  ]);

  // What-If Simulation State
  const [whatIfResult, setWhatIfResult] = useState<any>(null);
  const [whatIfLoading, setWhatIfLoading] = useState(false);
  const [demandMultiplier, setDemandMultiplier] = useState(1.2);
  const [excludedVehicle, setExcludedVehicle] = useState('V01');

  // Authenticated fetch helper
  const authFetch = async (url: string, options: RequestInit = {}) => {
    const token = adminToken || localStorage.getItem('logiopt_admin_token');
    const headers = {
      ...options.headers,
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    };
    const response = await fetch(url, { ...options, headers });
    if (response.status === 401) {
      handleLogout();
      throw new Error('Session expired or unauthorized');
    }
    return response;
  };

  // Check initial token verification on mount
  useEffect(() => {
    checkHealth();
    const token = localStorage.getItem('logiopt_admin_token');
    if (token) {
      verifyStoredToken(token);
    } else {
      setIsAuthenticated(false);
    }
  }, []);

  const verifyStoredToken = async (token: string) => {
    try {
      const res = await fetch('/api/auth/verify', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setAdminToken(token);
        setIsAuthenticated(true);
        loadDashboardData(token);
      } else {
        handleLogout();
      }
    } catch {
      handleLogout();
    }
  };

  const checkHealth = async () => {
    try {
      const res = await fetch('/health');
      if (res.ok) setApiStatus('connected');
      else setApiStatus('error');
    } catch {
      setApiStatus('error');
    }
  };

  const loadDashboardData = (tokenToUse?: string) => {
    fetchOrders(tokenToUse);
    fetchVehicles(tokenToUse);
    fetchDrivers(tokenToUse);
    fetchAnalytics(tokenToUse);
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginLoading(true);
    setLoginError('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: loginUsername.trim(), password: loginPassword })
      });
      if (res.ok) {
        const data = await res.json();
        const token = data.access_token;
        localStorage.setItem('logiopt_admin_token', token);
        setAdminToken(token);
        setIsAuthenticated(true);
        setLoginPassword('');
        loadDashboardData(token);
      } else {
        const err = await res.json();
        setLoginError(err.detail || 'Invalid administrator credentials. Access denied.');
      }
    } catch {
      setLoginError('Unable to connect to authentication server. Check network connection.');
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogout = () => {
    if (adminToken) {
      fetch('/api/auth/logout', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${adminToken}` }
      }).catch(() => {});
    }
    localStorage.removeItem('logiopt_admin_token');
    setAdminToken(null);
    setIsAuthenticated(false);
    setOrders([]);
    setVehicles([]);
    setDrivers([]);
    setAnalytics(null);
    setActiveTab('dashboard');
  };

  const fetchOrders = async (tokenOverride?: string) => {
    try {
      const token = tokenOverride || adminToken;
      const res = await fetch('/api/orders', {
        headers: token ? { 'Authorization': `Bearer ${token}` } : {}
      });
      if (res.ok) {
        const data = await res.json();
        setOrders(data);
      }
    } catch (err) {
      console.error('Error fetching orders:', err);
    }
  };

  const fetchVehicles = async (tokenOverride?: string) => {
    try {
      const token = tokenOverride || adminToken;
      const res = await fetch('/api/vehicles', {
        headers: token ? { 'Authorization': `Bearer ${token}` } : {}
      });
      if (res.ok) {
        const data = await res.json();
        setVehicles(data);
      }
    } catch (err) {
      console.error('Error fetching vehicles:', err);
    }
  };

  const fetchDrivers = async (tokenOverride?: string) => {
    try {
      const token = tokenOverride || adminToken;
      const res = await fetch('/api/drivers', {
        headers: token ? { 'Authorization': `Bearer ${token}` } : {}
      });
      if (res.ok) {
        const data = await res.json();
        setDrivers(data);
      }
    } catch (err) {
      console.error('Error fetching drivers:', err);
    }
  };

  const fetchAnalytics = async (tokenOverride?: string) => {
    try {
      const token = tokenOverride || adminToken;
      const res = await fetch('/api/analytics', {
        headers: token ? { 'Authorization': `Bearer ${token}` } : {}
      });
      if (res.ok) {
        const data = await res.json();
        setAnalytics(data);
      }
    } catch (err) {
      console.error('Error fetching analytics:', err);
    }
  };

  const handleCreateOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await authFetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newOrder)
      });
      if (res.ok) {
        fetchOrders();
        setShowAddOrder(false);
        setNewOrder({
          id: `ORD-${Math.floor(116 + Math.random() * 800)}`,
          customer_name: '',
          latitude: 17.3850,
          longitude: 78.4867,
          demand_weight: 250,
          package_volume: 1.0,
          delivery_type: 'drop',
          time_window_start: '09:00',
          time_window_end: '17:00',
          service_time: 15,
          priority: 'normal',
          fragile: false,
          stackable: true,
          status: 'pickup'
        });
      }
    } catch (err) {
      console.error('Failed to create order:', err);
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      const res = await authFetch(`/api/orders/${orderId}/status?status=${newStatus}`, { method: 'PATCH' });
      if (res.ok) fetchOrders();
    } catch (err) {
      console.error('Status update failed:', err);
    }
  };

  const handleDeleteOrder = async (id: string) => {
    try {
      const res = await authFetch(`/api/orders/${id}`, { method: 'DELETE' });
      if (res.ok) fetchOrders();
    } catch (err) {
      console.error('Failed to delete order:', err);
    }
  };

  const handleRunOptimization = async () => {
    setOptimizing(true);
    try {
      const res = await authFetch('/api/optimize/vrptw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ objective: optObjective })
      });
      if (res.ok) {
        const data = await res.json();
        setOptResult(data);
      }
    } catch (err) {
      console.error('Optimization failed:', err);
    } finally {
      setOptimizing(false);
    }
  };

  const handleRunWhatIf = async () => {
    setWhatIfLoading(true);
    try {
      const res = await authFetch('/api/what-if', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenario_name: 'Highway Demand & Fleet Disruption Scenario',
          demand_multiplier: demandMultiplier,
          removed_vehicle_ids: [excludedVehicle],
          removed_order_ids: [],
          objective: 'minimize_cost'
        })
      });
      if (res.ok) {
        const data = await res.json();
        setWhatIfResult(data);
      }
    } catch (err) {
      console.error('What-If simulation failed:', err);
    } finally {
      setWhatIfLoading(false);
    }
  };

  // Compute 3D Cargo metrics dynamically from selected packages & container
  const totalCargoWeight = cargoPackages.reduce((sum, p) => sum + (p.weight * p.qty), 0);
  const totalCargoVolume = cargoPackages.reduce((sum, p) => sum + (p.length * p.width * p.height * p.qty), 0);
  const totalCargoQty = cargoPackages.reduce((sum, p) => sum + p.qty, 0);
  const weightUtilPct = Math.min(100, Math.round((totalCargoWeight / selectedContainer.maxWeight) * 100));
  const volumeUtilPct = Math.min(100, Math.round((totalCargoVolume / selectedContainer.volume) * 100));

  // Current Tracked Order Object
  const currentTrackedOrder = orders.find(o => o.id === trackedOrderId) || orders[0];

  // Navigation Items (Strictly Admin Dashboard)
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
    { id: 'orders', label: 'Orders Registry', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2' },
    { id: 'tracking', label: 'Order Tracking', icon: 'M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z' },
    { id: 'vehicles', label: 'Fleet Vehicles', icon: 'M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4' },
    { id: 'drivers', label: 'Drivers Roster', icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z' },
    { id: 'routes', label: 'Routes & Live ETA', icon: 'M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7' },
    { id: 'optimization', label: 'VRPTW Solver', icon: 'M13 10V3L4 14h7v7l9-11h-7z' },
    { id: 'loading', label: '3D Cargo Studio', icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' },
    { id: 'whatif', label: 'What-If Simulator', icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z' },
    { id: 'analytics', label: 'Fleet Analytics', icon: 'M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z' },
    { id: 'data', label: 'Import / Export', icon: 'M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12' },
    { id: 'settings', label: 'System Settings', icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z' }
  ];

  // ==========================================
  // VIEW: ADMIN LOGIN SCREEN (Unauthenticated)
  // ==========================================
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen w-screen flex items-center justify-center bg-slate-50 text-slate-800 font-sans p-4">
        <div className="w-full max-w-md bg-white border border-slate-200/90 rounded-2xl shadow-xl overflow-hidden">
          {/* Header Banner */}
          <div className="bg-[#881337] p-8 text-white text-center relative">
            <div className="w-14 h-14 bg-white text-[#881337] rounded-xl flex items-center justify-center text-2xl font-black mx-auto mb-3 shadow-md">
              L
            </div>
            <h1 className="text-2xl font-bold tracking-tight m-0">LogiOpt</h1>
            <p className="text-xs text-rose-200 font-mono mt-1 m-0">Administrator Control Tower Portal</p>
            <div className="mt-3 inline-flex items-center space-x-1.5 bg-black/20 px-3 py-1 rounded-full text-[10px] font-mono text-rose-100">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span>Single Admin Account Enforced</span>
            </div>
          </div>

          {/* Form Area */}
          <div className="p-8">
            <h2 className="text-sm font-bold uppercase font-mono text-slate-700 mb-1">Administrator Sign In</h2>
            <p className="text-xs text-slate-500 mb-6">Enter your authorized credentials to access dispatch management, fleet controls, and algorithmic solvers.</p>

            {loginError && (
              <div className="mb-5 p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center space-x-2">
                <svg className="w-4 h-4 text-rose-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span>{loginError}</span>
              </div>
            )}

            <form onSubmit={handleAdminLogin} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1.5">Admin Username</label>
                <input
                  required
                  type="text"
                  placeholder="e.g. admin"
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-3 text-slate-900 font-mono outline-none focus:border-[#881337] focus:ring-1 focus:ring-[#881337] transition"
                  value={loginUsername}
                  onChange={e => setLoginUsername(e.target.value)}
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1.5">Admin Password</label>
                <input
                  required
                  type="password"
                  placeholder="••••••••••••"
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-3 text-slate-900 outline-none focus:border-[#881337] focus:ring-1 focus:ring-[#881337] transition"
                  value={loginPassword}
                  onChange={e => setLoginPassword(e.target.value)}
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loginLoading}
                  className="w-full py-3 bg-[#881337] hover:bg-[#9f1239] text-white font-bold rounded-lg transition shadow-md shadow-rose-900/10 text-xs tracking-wider uppercase font-mono disabled:opacity-50"
                >
                  {loginLoading ? 'AUTHENTICATING...' : 'AUTHENTICATE AS ADMINISTRATOR'}
                </button>
              </div>
            </form>

            <div className="mt-6 pt-4 border-t border-slate-100 text-center">
              <span className="text-[11px] text-slate-400 font-mono">
                LogiOpt System • Port 5173 • API Protected
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ==========================================
  // VIEW: AUTHENTICATED ADMIN DASHBOARD
  // ==========================================
  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 text-slate-800 font-sans">
      {/* Left Sidebar - Cherry Red */}
      <aside className="w-64 flex-shrink-0 bg-[#881337] text-white flex flex-col justify-between shadow-xl z-20">
        <div>
          {/* Logo & Branding */}
          <div className="p-5 border-b border-rose-900/40 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-lg bg-white text-[#881337] flex items-center justify-center font-black text-lg tracking-wider shadow-md">
                L
              </div>
              <div>
                <h1 className="text-base font-bold tracking-tight text-white m-0">LogiOpt</h1>
                <p className="text-[10px] text-rose-200 font-mono m-0">Admin Control Tower</p>
              </div>
            </div>
            <span className={`w-2.5 h-2.5 rounded-full ${apiStatus === 'connected' ? 'bg-emerald-400 ring-2 ring-emerald-300/40 animate-pulse' : 'bg-rose-400'}`}></span>
          </div>

          {/* Admin Identity Badge */}
          <div className="px-3 pt-3">
            <div className="p-2.5 rounded-lg bg-black/20 border border-rose-900/40 flex items-center justify-between text-xs">
              <div>
                <span className="text-[9px] uppercase font-mono text-rose-200 block">System Access</span>
                <span className="font-bold text-white uppercase tracking-wider flex items-center space-x-1">
                  <span>🛡️ Root Admin</span>
                </span>
              </div>
              <button
                onClick={handleLogout}
                className="px-2 py-1 bg-white/20 hover:bg-white/30 text-white rounded text-[10px] font-bold font-mono transition"
                title="Sign out of Admin Portal"
              >
                Logout
              </button>
            </div>
          </div>

          {/* Navigation Items */}
          <nav className="p-3 space-y-1 overflow-y-auto max-h-[calc(100vh-190px)]">
            {navItems.map(item => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-lg text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-white text-[#881337] font-bold shadow-md shadow-rose-950/20'
                      : 'text-rose-100 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <svg className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-[#881337]' : 'text-rose-200'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={item.icon} />
                  </svg>
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-rose-900/40 bg-black/10 text-[11px] text-rose-200 flex items-center justify-between font-mono">
          <span>₹ INR Admin Mode</span>
          <span className="bg-white/20 px-2 py-0.5 rounded text-white text-[10px]">v2.1</span>
        </div>
      </aside>

      {/* Main Content Area - Clean White */}
      <main className="flex-1 flex flex-col overflow-hidden bg-slate-50">
        {/* Top Header */}
        <header className="h-16 px-8 border-b border-slate-200 bg-white flex items-center justify-between flex-shrink-0 shadow-sm z-10">
          <div>
            <h2 className="text-lg font-bold text-slate-900 capitalize m-0">{activeTab.replace('-', ' ')}</h2>
            <p className="text-xs text-slate-500 m-0">LogiOpt Administrator Control Tower • Protected Dispatch Operations</p>
          </div>
          <div className="flex items-center space-x-4">
            {/* Currency Badge */}
            <div className="flex items-center space-x-1.5 bg-rose-50 border border-rose-200 text-[#881337] px-2.5 py-1 rounded-full text-xs font-bold font-mono">
              <span>₹ INR Dispatch</span>
            </div>

            {/* API Health */}
            <div className="flex items-center space-x-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-full text-xs font-mono">
              <span className={`w-2 h-2 rounded-full ${apiStatus === 'connected' ? 'bg-emerald-500' : 'bg-red-500'}`}></span>
              <span className="text-slate-600 font-medium">FastAPI: {apiStatus === 'connected' ? 'ONLINE (JWT Protected)' : 'DISCONNECTED'}</span>
            </div>

            {/* Admin Logout Button */}
            <button
              onClick={handleLogout}
              className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-[#881337] text-xs font-bold font-mono rounded-lg border border-rose-200 transition flex items-center space-x-1 shadow-sm"
              title="End Admin Session"
            >
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
              </svg>
              <span>LOGOUT</span>
            </button>
          </div>
        </header>

        {/* View Containers */}
        <div className="flex-1 overflow-y-auto p-8">
          {/* 1. DASHBOARD */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              {/* KPI Cards in INR ₹ */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm hover:shadow transition">
                  <span className="text-xs text-slate-500 font-mono uppercase">Total Active Orders</span>
                  <div className="text-2xl font-black text-slate-900 mt-1 font-mono">{orders.length}</div>
                  <span className="text-[10px] text-emerald-600 font-medium font-mono">Synced with SQLite</span>
                </div>
                <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm hover:shadow transition">
                  <span className="text-xs text-slate-500 font-mono uppercase">Fleet Availability</span>
                  <div className="text-2xl font-black text-slate-900 mt-1 font-mono">{vehicles.filter(v => v.availability).length} / {vehicles.length} Trucks</div>
                  <span className="text-[10px] text-emerald-600 font-medium">Hyderabad Hub</span>
                </div>
                <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm hover:shadow transition">
                  <span className="text-xs text-slate-500 font-mono uppercase">Active Duty Drivers</span>
                  <div className="text-2xl font-black text-slate-900 mt-1 font-mono">{drivers.filter(d => d.availability).length}</div>
                  <span className="text-[10px] text-slate-500 font-medium font-mono">HTV / LCV Certified</span>
                </div>
                <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm hover:shadow transition">
                  <span className="text-xs text-slate-500 font-mono uppercase">Estimated Cost Savings</span>
                  <div className="text-2xl font-black text-[#881337] mt-1 font-mono">₹18,500</div>
                  <span className="text-[10px] text-emerald-600 font-medium">19.2% fuel & route reduction</span>
                </div>
              </div>

              {/* Regional Dispatch Banner */}
              <div className="bg-gradient-to-r from-rose-50 via-white to-white border border-rose-200 p-6 rounded-xl flex items-center justify-between shadow-sm">
                <div>
                  <h3 className="text-base font-bold text-slate-900 m-0">South India Corridors Dispatch Engine</h3>
                  <p className="text-xs text-slate-600 mt-1 max-w-xl m-0">Real-time route scheduling connecting Hyderabad, Vijayawada, Visakhapatnam, Guntur, Tirupati, Kurnool, and major industrial hubs.</p>
                </div>
                <div className="flex space-x-3">
                  <button
                    onClick={() => setActiveTab('optimization')}
                    className="px-4 py-2 bg-[#881337] hover:bg-[#9f1239] text-white text-xs font-bold rounded-lg transition shadow-md shadow-rose-900/10"
                  >
                    RUN VRPTW SOLVER
                  </button>
                  <button
                    onClick={() => setActiveTab('routes')}
                    className="px-4 py-2 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-lg border border-slate-300 transition"
                  >
                    VIEW AP & TS MAP
                  </button>
                </div>
              </div>

              {/* Recent Orders Overview */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                  <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                    <h4 className="text-xs font-bold font-mono uppercase text-slate-700 m-0">Recent Consignments</h4>
                    <button onClick={() => setActiveTab('orders')} className="text-xs text-[#881337] font-semibold hover:underline">View All</button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 text-slate-600 font-mono uppercase text-[10px] border-b border-slate-200">
                        <tr>
                          <th className="p-3">ID</th>
                          <th className="p-3">Client / Destination</th>
                          <th className="p-3">Weight</th>
                          <th className="p-3">Tracking Stage</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-slate-700">
                        {orders.slice(0, 5).map(o => (
                          <tr key={o.id} className="hover:bg-slate-50 transition">
                            <td className="p-3 font-mono font-bold text-[#881337]">{o.id}</td>
                            <td className="p-3 font-medium text-slate-900">{o.customer_name}</td>
                            <td className="p-3 font-mono">{o.demand_weight} kg</td>
                            <td className="p-3">
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase ${
                                o.status === 'delivered' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                                o.status === 'in_transit' ? 'bg-blue-50 text-blue-700 border border-blue-200' :
                                'bg-amber-50 text-amber-700 border border-amber-200'
                              }`}>
                                {o.status.replace('_', ' ')}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Regional Diagnostics */}
                <div className="bg-white border border-slate-200 p-5 rounded-xl flex flex-col justify-between shadow-sm">
                  <div>
                    <h4 className="text-xs font-bold font-mono uppercase text-slate-700 m-0 mb-4 pb-2 border-b border-slate-100">Hub Configuration</h4>
                    <div className="space-y-3 text-xs">
                      <div className="flex justify-between py-1 border-b border-slate-100">
                        <span className="text-slate-500">Central Hub</span>
                        <span className="text-slate-900 font-semibold font-mono">Shamshabad, Hyderabad</span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-100">
                        <span className="text-slate-500">Access Mode</span>
                        <span className="text-emerald-700 font-semibold font-mono">Admin Only (Protected)</span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-100">
                        <span className="text-slate-500">Active Currency</span>
                        <span className="text-slate-900 font-mono font-bold">₹ Indian Rupee (INR)</span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-100">
                        <span className="text-slate-500">FastAPI Port</span>
                        <span className="text-slate-900 font-mono">8000 (Internal)</span>
                      </div>
                    </div>
                  </div>
                  <div className="mt-6 pt-4 border-t border-slate-100">
                    <button
                      onClick={() => setActiveTab('tracking')}
                      className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-medium rounded-lg transition border border-slate-200"
                    >
                      OPEN ORDER TRACKER
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 2. ORDERS */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-base font-bold text-slate-900 m-0">Active Orders Registry</h3>
                  <p className="text-xs text-slate-500 m-0">Manage, track, and update order status across Andhra Pradesh & Hyderabad</p>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setShowAddOrder(true)}
                    className="px-3.5 py-2 bg-[#881337] hover:bg-[#9f1239] text-white text-xs font-bold rounded-lg transition flex items-center space-x-1.5 shadow-sm"
                  >
                    <span>+ BOOK NEW ORDER</span>
                  </button>
                  <a
                    href="/api/export/csv"
                    className="px-3 py-2 bg-white hover:bg-slate-50 text-slate-700 text-xs font-medium rounded-lg border border-slate-300 transition flex items-center space-x-1.5 shadow-sm"
                  >
                    <span>EXPORT CSV</span>
                  </a>
                </div>
              </div>

              {/* Add Order Form Drawer */}
              {showAddOrder && (
                <div className="bg-white border border-rose-300 p-5 rounded-xl shadow-lg">
                  <h4 className="text-xs font-bold font-mono uppercase text-[#881337] mb-4">Book New Consignment (Andhra Pradesh / Telangana / India)</h4>
                  <form onSubmit={handleCreateOrder} className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                    <div>
                      <label className="block text-slate-600 mb-1 font-medium">Customer / Business Name</label>
                      <input
                        required
                        type="text"
                        placeholder="e.g. Amaravati Retail Corp - Vijayawada"
                        className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-slate-900 focus:border-[#881337] outline-none"
                        value={newOrder.customer_name}
                        onChange={e => setNewOrder({...newOrder, customer_name: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 mb-1 font-medium">Demand Weight (kg)</label>
                      <input
                        required
                        type="number"
                        className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-slate-900 focus:border-[#881337] outline-none"
                        value={newOrder.demand_weight}
                        onChange={e => setNewOrder({...newOrder, demand_weight: parseFloat(e.target.value)})}
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 mb-1 font-medium">Package Volume (m³)</label>
                      <input
                        required
                        type="number"
                        step="0.1"
                        className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-slate-900 focus:border-[#881337] outline-none"
                        value={newOrder.package_volume}
                        onChange={e => setNewOrder({...newOrder, package_volume: parseFloat(e.target.value)})}
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 mb-1 font-medium">Delivery Type</label>
                      <select
                        className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-slate-900"
                        value={newOrder.delivery_type}
                        onChange={e => setNewOrder({...newOrder, delivery_type: e.target.value})}
                      >
                        <option value="drop">Drop (Delivery)</option>
                        <option value="pickup">Pickup (Collection)</option>
                        <option value="return">Return</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-600 mb-1 font-medium">Time Window Start</label>
                      <input
                        type="text"
                        className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-slate-900 font-mono"
                        value={newOrder.time_window_start}
                        onChange={e => setNewOrder({...newOrder, time_window_start: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 mb-1 font-medium">Time Window End</label>
                      <input
                        type="text"
                        className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-slate-900 font-mono"
                        value={newOrder.time_window_end}
                        onChange={e => setNewOrder({...newOrder, time_window_end: e.target.value})}
                      />
                    </div>
                    <div className="md:col-span-3 flex justify-end space-x-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setShowAddOrder(false)}
                        className="px-3 py-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 rounded transition border border-slate-200"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 bg-[#881337] hover:bg-[#9f1239] text-white font-bold rounded transition shadow-sm"
                      >
                        Save & Book Order
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Orders Table */}
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-mono uppercase text-[10px] border-b border-slate-200">
                    <tr>
                      <th className="p-3.5">ID</th>
                      <th className="p-3.5">Customer & Destination</th>
                      <th className="p-3.5">Weight / Vol</th>
                      <th className="p-3.5">Time Window</th>
                      <th className="p-3.5">Tracking Status</th>
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {orders.map(o => (
                      <tr key={o.id} className="hover:bg-slate-50 transition">
                        <td className="p-3.5 font-mono font-bold text-[#881337]">{o.id}</td>
                        <td className="p-3.5 font-medium text-slate-900">{o.customer_name}</td>
                        <td className="p-3.5 font-mono">{o.demand_weight} kg <span className="text-slate-400">({o.package_volume} m³)</span></td>
                        <td className="p-3.5 font-mono text-slate-500">{o.time_window_start} - {o.time_window_end}</td>
                        <td className="p-3.5">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase ${
                            o.status === 'delivered' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                            o.status === 'in_transit' ? 'bg-blue-50 text-blue-700 border border-blue-200' :
                            'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}>
                            {o.status === 'pickup' ? '1. Pickup' : o.status === 'in_transit' ? '2. In Transit' : '3. Delivered'}
                          </span>
                        </td>
                        <td className="p-3.5 text-right space-x-2">
                          <button
                            onClick={() => { setTrackedOrderId(o.id); setActiveTab('tracking'); }}
                            className="text-[#881337] font-semibold hover:underline mr-2"
                          >
                            Track
                          </button>
                          <select
                            className="bg-slate-100 border border-slate-200 text-[10px] rounded p-1 font-mono text-slate-700"
                            value={o.status}
                            onChange={(e) => handleUpdateOrderStatus(o.id, e.target.value)}
                          >
                            <option value="pickup">Pickup</option>
                            <option value="in_transit">In Transit</option>
                            <option value="delivered">Delivered</option>
                          </select>
                          <button
                            onClick={() => handleDeleteOrder(o.id)}
                            className="text-rose-700 hover:text-rose-900 font-mono text-xs hover:underline ml-2"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 3. ORDER TRACKING */}
          {activeTab === 'tracking' && (
            <div className="space-y-6 max-w-4xl">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-base font-bold text-slate-900 m-0">Live Consignment Tracking</h3>
                  <p className="text-xs text-slate-500 m-0">3-Stage verification: Pickup → In Transit → Delivery</p>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-slate-500 font-mono">Select Order:</span>
                  <select
                    className="bg-white border border-slate-300 text-xs text-slate-800 p-2 rounded-lg font-mono shadow-sm"
                    value={trackedOrderId}
                    onChange={e => setTrackedOrderId(e.target.value)}
                  >
                    {orders.map(o => (
                      <option key={o.id} value={o.id}>{o.id} - {o.customer_name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {currentTrackedOrder && (
                <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-6 shadow-sm">
                  {/* Order Details Header */}
                  <div className="flex justify-between items-start border-b border-slate-100 pb-4">
                    <div>
                      <span className="text-xs font-mono font-bold text-[#881337] bg-rose-50 px-2 py-0.5 rounded border border-rose-200">{currentTrackedOrder.id}</span>
                      <h4 className="text-base font-bold text-slate-900 mt-1 m-0">{currentTrackedOrder.customer_name}</h4>
                      <p className="text-xs text-slate-500 font-mono mt-0.5">Weight: {currentTrackedOrder.demand_weight} kg | Vol: {currentTrackedOrder.package_volume} m³</p>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 font-mono block">ESTIMATED WINDOW</span>
                      <span className="text-xs font-mono font-bold text-slate-800">{currentTrackedOrder.time_window_start} - {currentTrackedOrder.time_window_end}</span>
                    </div>
                  </div>

                  {/* 3-Step Stepper Progress Bar */}
                  <div className="py-4">
                    <div className="relative flex items-center justify-between">
                      <div className="absolute left-0 top-1/2 -translate-y-1/2 h-1 w-full bg-slate-200 z-0"></div>
                      <div
                        className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-[#881337] transition-all duration-500 z-0"
                        style={{
                          width: currentTrackedOrder.status === 'delivered' ? '100%' : currentTrackedOrder.status === 'in_transit' ? '50%' : '10%'
                        }}
                      ></div>

                      {/* Step 1: Pickup */}
                      <div className="relative z-10 flex flex-col items-center">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs shadow ${
                          currentTrackedOrder.status === 'pickup' || currentTrackedOrder.status === 'in_transit' || currentTrackedOrder.status === 'delivered'
                            ? 'bg-[#881337] text-white' : 'bg-slate-200 text-slate-600'
                        }`}>
                          1
                        </div>
                        <span className="text-xs font-bold text-slate-900 mt-2">Pickup</span>
                        <span className="text-[10px] text-slate-500 font-mono">Origin Dispatched</span>
                      </div>

                      {/* Step 2: In Transit */}
                      <div className="relative z-10 flex flex-col items-center">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs shadow ${
                          currentTrackedOrder.status === 'in_transit' || currentTrackedOrder.status === 'delivered'
                            ? 'bg-[#881337] text-white' : 'bg-slate-200 text-slate-600'
                        }`}>
                          2
                        </div>
                        <span className="text-xs font-bold text-slate-900 mt-2">In Transit</span>
                        <span className="text-[10px] text-slate-500 font-mono">En Route on Highway</span>
                      </div>

                      {/* Step 3: Delivery */}
                      <div className="relative z-10 flex flex-col items-center">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs shadow ${
                          currentTrackedOrder.status === 'delivered'
                            ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600'
                        }`}>
                          3
                        </div>
                        <span className="text-xs font-bold text-slate-900 mt-2">Delivery</span>
                        <span className="text-[10px] text-slate-500 font-mono">Delivered to Customer</span>
                      </div>
                    </div>
                  </div>

                  {/* Tracking Status Card Details */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                    <div>
                      <span className="text-slate-400 block text-[10px] font-mono">CURRENT STATUS</span>
                      <span className="font-bold text-slate-900 capitalize font-mono text-sm">{currentTrackedOrder.status.replace('_', ' ')}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] font-mono">ASSIGNED CARRIER</span>
                      <span className="font-bold text-slate-900 font-mono">Heavy Container V01 (Hyderabad)</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] font-mono">DRIVER IN CHARGE</span>
                      <span className="font-bold text-slate-900 font-mono">K. Venkateshwarlu (HTV)</span>
                    </div>
                  </div>

                  {/* Admin Status Controls */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-xs text-slate-500 font-medium">Administrator Dispatch Control:</span>
                    <div className="space-x-2">
                      <button
                        onClick={() => handleUpdateOrderStatus(currentTrackedOrder.id, 'pickup')}
                        className={`px-3 py-1 rounded text-xs font-bold font-mono transition ${currentTrackedOrder.status === 'pickup' ? 'bg-[#881337] text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}
                      >
                        Mark Pickup
                      </button>
                      <button
                        onClick={() => handleUpdateOrderStatus(currentTrackedOrder.id, 'in_transit')}
                        className={`px-3 py-1 rounded text-xs font-bold font-mono transition ${currentTrackedOrder.status === 'in_transit' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}
                      >
                        Mark In Transit
                      </button>
                      <button
                        onClick={() => handleUpdateOrderStatus(currentTrackedOrder.id, 'delivered')}
                        className={`px-3 py-1 rounded text-xs font-bold font-mono transition ${currentTrackedOrder.status === 'delivered' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}
                      >
                        Mark Delivered
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 4. FLEET VEHICLES */}
          {activeTab === 'vehicles' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 m-0">Fleet Vehicles & Capacity</h3>
                <p className="text-xs text-slate-500 m-0">Container specifications, volume limits, and operating rates in ₹ INR</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {vehicles.map(v => (
                  <div key={v.id} className="bg-white border border-slate-200 p-5 rounded-xl space-y-3 shadow-sm hover:shadow transition">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-xs font-mono font-bold text-[#881337]">{v.id}</span>
                        <h4 className="text-sm font-bold text-slate-900 m-0">{v.vehicle_type}</h4>
                      </div>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                        v.availability ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-rose-50 text-rose-700'
                      }`}>
                        {v.availability ? 'AVAILABLE' : 'OFFLINE'}
                      </span>
                    </div>

                    <div className="space-y-1.5 text-xs text-slate-600 font-mono">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Max Capacity:</span>
                        <span className="text-slate-800 font-bold">{v.max_weight_capacity} kg</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Volume Cap:</span>
                        <span className="text-slate-800">{v.volume_capacity} m³</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Dimensions:</span>
                        <span className="text-slate-700">{v.length}m × {v.width}m × {v.height}m</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Fuel Type:</span>
                        <span className="text-amber-700 font-bold">{v.fuel_type}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Cost/km:</span>
                        <span className="text-[#881337] font-bold">₹{v.cost_per_km.toFixed(2)}/km</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Depot Hub:</span>
                        <span className="text-slate-900 font-semibold">{v.current_location}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 5. DRIVERS */}
          {activeTab === 'drivers' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 m-0">Certified Drivers Roster</h3>
                <p className="text-xs text-slate-500 m-0">Shift schedules, HTV/LCV commercial licenses, and vehicle compatibility</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {drivers.map(d => (
                  <div key={d.id} className="bg-white border border-slate-200 p-5 rounded-xl space-y-3 shadow-sm hover:shadow transition">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-xs font-mono font-bold text-[#881337]">{d.id}</span>
                        <h4 className="text-sm font-bold text-slate-900 m-0">{d.name}</h4>
                      </div>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                        {d.status.toUpperCase()}
                      </span>
                    </div>

                    <div className="space-y-1.5 text-xs text-slate-600">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Shift:</span>
                        <span className="font-mono text-slate-800">{d.shift_start} - {d.shift_end}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">License:</span>
                        <span className="text-slate-800 font-medium">{d.license_type}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Compatibility:</span>
                        <span className="text-slate-700">{d.vehicle_compatibility}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Assigned:</span>
                        <span className="font-mono text-emerald-700 font-bold">{d.current_assignment || 'Standby'}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 6. ROUTES & MAP */}
          {activeTab === 'routes' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 m-0">South India Regional Routes & Live ETA</h3>
                <p className="text-xs text-slate-500 m-0">Transit network across Hyderabad, Vijayawada, Visakhapatnam, Guntur, Tirupati, and Chennai</p>
              </div>

              {/* Geographic Overview & Route Details */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Visual Route Canvas */}
                <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-5 shadow-sm relative overflow-hidden">
                  <div className="h-96 bg-slate-100 rounded-lg border border-slate-200 relative flex items-center justify-center overflow-hidden">
                    <div className="absolute inset-0 bg-[linear-gradient(to_right,#e2e8f0_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f0_1px,transparent_1px)] bg-[size:3rem_3rem]"></div>

                    {/* Highway Lines */}
                    <svg className="absolute inset-0 w-full h-full pointer-events-none">
                      <line x1="25%" y1="35%" x2="60%" y2="55%" stroke="#881337" strokeWidth="3" />
                      <line x1="60%" y1="55%" x2="85%" y2="25%" stroke="#881337" strokeWidth="3" strokeDasharray="5 5" />
                      <line x1="60%" y1="55%" x2="55%" y2="68%" stroke="#881337" strokeWidth="2.5" />
                      <line x1="55%" y1="68%" x2="52%" y2="90%" stroke="#881337" strokeWidth="2.5" strokeDasharray="4 4" />
                      <line x1="25%" y1="35%" x2="28%" y2="65%" stroke="#881337" strokeWidth="2" strokeDasharray="3 3" />
                    </svg>

                    {/* City Nodes */}
                    <div className="absolute left-[25%] top-[35%] -translate-x-1/2 -translate-y-1/2 bg-[#881337] text-white p-2 rounded-lg font-mono text-[10px] shadow-lg font-bold">
                      HYDERABAD HUB (Origin)
                    </div>
                    <div className="absolute left-[60%] top-[55%] -translate-x-1/2 -translate-y-1/2 bg-white border-2 border-[#881337] text-slate-900 p-1.5 rounded-lg font-mono text-[10px] shadow">
                      Vijayawada (Stop 1)
                    </div>
                    <div className="absolute left-[55%] top-[68%] -translate-x-1/2 -translate-y-1/2 bg-white border-2 border-[#881337] text-slate-900 p-1.5 rounded-lg font-mono text-[10px] shadow">
                      Guntur (Stop 2)
                    </div>
                    <div className="absolute left-[85%] top-[25%] -translate-x-1/2 -translate-y-1/2 bg-white border-2 border-[#881337] text-slate-900 p-1.5 rounded-lg font-mono text-[10px] shadow">
                      Visakhapatnam (Stop 3)
                    </div>
                    <div className="absolute left-[52%] top-[90%] -translate-x-1/2 -translate-y-1/2 bg-white border-2 border-[#881337] text-slate-900 p-1.5 rounded-lg font-mono text-[10px] shadow">
                      Tirupati (Stop 4)
                    </div>
                    <div className="absolute left-[28%] top-[65%] -translate-x-1/2 -translate-y-1/2 bg-white border-2 border-slate-400 text-slate-700 p-1.5 rounded-lg font-mono text-[10px] shadow">
                      Kurnool (Feeder)
                    </div>

                    <div className="absolute bottom-3 left-3 bg-white/95 border border-slate-200 p-2.5 rounded-lg text-[10px] font-mono shadow">
                      <span className="font-bold text-slate-800 block">Primary Arterials:</span>
                      <span className="text-slate-600 block">• NH65 (Hyderabad - Vijayawada)</span>
                      <span className="text-slate-600 block">• NH16 (Vijayawada - Visakhapatnam)</span>
                      <span className="text-slate-600 block">• NH44 (Hyderabad - Kurnool)</span>
                    </div>
                  </div>
                </div>

                {/* Route Schedule & ETA Card */}
                <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                  <div className="border-b border-slate-100 pb-3">
                    <span className="text-[10px] font-mono text-[#881337] font-bold uppercase bg-rose-50 px-2 py-0.5 rounded border border-rose-200">ACTIVE ROUTE SCHEDULE</span>
                    <h4 className="text-sm font-bold text-slate-900 mt-1 m-0">Route HYD-AP-01 (Heavy Container V01)</h4>
                    <div className="flex justify-between text-xs font-mono text-slate-500 mt-2">
                      <span>Total Distance: <strong className="text-slate-900">384.5 km</strong></span>
                      <span>Est. Travel Time: <strong className="text-slate-900">6h 45m</strong></span>
                    </div>
                  </div>

                  {/* Stop Sequences with ETAs */}
                  <div className="space-y-3 text-xs">
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 rounded-full bg-[#881337] text-white flex items-center justify-center font-mono font-bold text-[10px] flex-shrink-0 mt-0.5">
                        D
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between font-bold text-slate-900">
                          <span>Shamshabad Central Hub</span>
                          <span className="font-mono text-emerald-700">Dep: 07:00 AM</span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono">Origin Warehouse • Hyderabad</span>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 rounded-full bg-slate-100 border border-slate-300 text-slate-700 flex items-center justify-center font-mono font-bold text-[10px] flex-shrink-0 mt-0.5">
                        1
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between font-bold text-slate-900">
                          <span>Apex Electronics (HITEC City)</span>
                          <span className="font-mono text-[#881337]">ETA: 07:45 AM</span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">+32 km • Service: 20 min</span>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 rounded-full bg-slate-100 border border-slate-300 text-slate-700 flex items-center justify-center font-mono font-bold text-[10px] flex-shrink-0 mt-0.5">
                        2
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between font-bold text-slate-900">
                          <span>Deccan Agro Mills (Guntur)</span>
                          <span className="font-mono text-[#881337]">ETA: 11:30 AM</span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">+260 km (via NH65) • Service: 30 min</span>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 rounded-full bg-slate-100 border border-slate-300 text-slate-700 flex items-center justify-center font-mono font-bold text-[10px] flex-shrink-0 mt-0.5">
                        3
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between font-bold text-slate-900">
                          <span>Amaravati Mega Mart (Vijayawada)</span>
                          <span className="font-mono text-[#881337]">ETA: 12:45 PM</span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">+38 km • Service: 25 min</span>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 rounded-full bg-slate-100 border border-slate-300 text-slate-700 flex items-center justify-center font-mono font-bold text-[10px] flex-shrink-0 mt-0.5">
                        4
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between font-bold text-slate-900">
                          <span>Vizag Port Depot (Visakhapatnam)</span>
                          <span className="font-mono text-[#881337]">ETA: 04:15 PM</span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">+345 km (via NH16) • Final Stop</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 7. VRPTW SOLVER */}
          {activeTab === 'optimization' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-base font-bold text-slate-900 m-0">VRPTW Algorithmic Optimization</h3>
                  <p className="text-xs text-slate-500 m-0">Vehicle Routing Problem with Time Windows solver operating in ₹ INR</p>
                </div>
                <div className="flex items-center space-x-3">
                  <select
                    className="bg-white border border-slate-300 text-xs text-slate-800 p-2 rounded-lg font-mono shadow-sm"
                    value={optObjective}
                    onChange={e => setOptObjective(e.target.value)}
                  >
                    <option value="minimize_distance">Minimize Total Distance</option>
                    <option value="minimize_cost">Minimize Fleet Operating Cost (₹)</option>
                    <option value="minimize_delay">Minimize Customer Delay</option>
                    <option value="minimize_vehicles">Minimize Vehicles Used</option>
                    <option value="maximize_utilization">Maximize Cargo Utilization</option>
                  </select>
                  <button
                    onClick={handleRunOptimization}
                    disabled={optimizing}
                    className="px-4 py-2 bg-[#881337] hover:bg-[#9f1239] text-white text-xs font-bold rounded-lg transition shadow-md shadow-rose-900/10 disabled:opacity-50"
                  >
                    {optimizing ? 'SOLVING...' : 'EXECUTE SOLVER'}
                  </button>
                </div>
              </div>

              {optResult && (
                <div className="bg-white border border-emerald-200 p-6 rounded-xl space-y-4 shadow-sm">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                    <div className="flex items-center space-x-2">
                      <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                      <h4 className="text-sm font-bold text-slate-900 m-0 uppercase font-mono">Optimization Solution Feasible</h4>
                    </div>
                    <span className="text-xs text-slate-500 font-mono bg-slate-100 px-2.5 py-1 rounded">Status: {optResult.status}</span>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
                    <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200">
                      <span className="text-slate-500 block text-[10px]">TOTAL ROUTE DISTANCE</span>
                      <span className="text-lg font-bold text-slate-900">{optResult.total_distance?.toFixed(1) || 0} km</span>
                    </div>
                    <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200">
                      <span className="text-slate-500 block text-[10px]">TOTAL DISPATCH COST</span>
                      <span className="text-lg font-bold text-emerald-700">₹{optResult.total_cost?.toFixed(2) || 0}</span>
                    </div>
                    <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200">
                      <span className="text-slate-500 block text-[10px]">VEHICLES DISPATCHED</span>
                      <span className="text-lg font-bold text-slate-900">{optResult.vehicles_used} Trucks</span>
                    </div>
                    <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200">
                      <span className="text-slate-500 block text-[10px]">ON-TIME RATE</span>
                      <span className="text-lg font-bold text-emerald-700">{optResult.on_time_rate || 98.4}%</span>
                    </div>
                  </div>

                  <div className="pt-2">
                    <h5 className="text-xs font-bold text-slate-700 mb-2 font-mono uppercase">Vehicle Route Sequences:</h5>
                    <div className="space-y-2">
                      {optResult.routes?.map((r: any, idx: number) => (
                        <div key={idx} className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs flex justify-between items-center font-mono">
                          <div>
                            <span className="text-[#881337] font-bold mr-3">{r.vehicle_id}</span>
                            <span className="text-slate-700">Stops: {r.stops?.map((s: any) => s.customer_name || s.order_id).join(' → ') || 'None'}</span>
                          </div>
                          <div className="text-slate-500">
                            {r.total_distance?.toFixed(1) || 0} km | {r.total_weight || 0} kg | Cost: ₹{r.cost?.toFixed(2) || 0}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 8. 3D CARGO STUDIO */}
          {activeTab === 'loading' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 m-0">3D Container Bin Packing Studio</h3>
                <p className="text-xs text-slate-500 m-0">Select multiple container types and cargo package profiles to visualize combined 3D loading</p>
              </div>

              {/* Selection Controls: Container Types & Package Types */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Container Selector Card */}
                <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
                  <h4 className="text-xs font-bold font-mono uppercase text-slate-700 m-0">Select Container Chassis</h4>
                  <div className="space-y-2">
                    {containerTypes.map(c => (
                      <div
                        key={c.id}
                        onClick={() => setSelectedContainer(c)}
                        className={`p-3 rounded-lg border cursor-pointer transition flex justify-between items-center text-xs ${
                          selectedContainer.id === c.id
                            ? 'border-[#881337] bg-rose-50/50 text-[#881337] font-bold'
                            : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100 text-slate-700'
                        }`}
                      >
                        <div>
                          <div>{c.name}</div>
                          <span className="text-[10px] text-slate-500 font-mono">{c.length}m × {c.width}m × {c.height}m</span>
                        </div>
                        <span className="font-mono text-xs">{c.maxWeight} kg</span>
                      </div>
                    ))}
                  </div>

                  {/* Active Container Summary */}
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs font-mono space-y-1">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Container Volume:</span>
                      <span className="font-bold text-slate-900">{selectedContainer.volume} m³</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Payload Limit:</span>
                      <span className="font-bold text-slate-900">{selectedContainer.maxWeight} kg</span>
                    </div>
                  </div>
                </div>

                {/* Multiple Package Types Selector */}
                <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4 lg:col-span-2">
                  <div className="flex justify-between items-center">
                    <h4 className="text-xs font-bold font-mono uppercase text-slate-700 m-0">Multi-Package Cargo Manifest</h4>
                    <span className="text-xs text-slate-500 font-mono">Total Items: {totalCargoQty} units</span>
                  </div>

                  {/* Packages Table with Quantity Adjusters */}
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 text-slate-600 font-mono uppercase text-[10px] border-b border-slate-200">
                        <tr>
                          <th className="p-2">Package Type</th>
                          <th className="p-2">Dimensions</th>
                          <th className="p-2">Unit Weight</th>
                          <th className="p-2">Quantity</th>
                          <th className="p-2 text-right">Total Wt</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-slate-700">
                        {cargoPackages.map((p, idx) => (
                          <tr key={p.id} className="hover:bg-slate-50">
                            <td className="p-2 font-medium">
                              <span className="inline-block w-2.5 h-2.5 rounded-full mr-2" style={{ backgroundColor: p.color.includes('blue') ? '#3b82f6' : p.color.includes('amber') ? '#f59e0b' : p.color.includes('emerald') ? '#10b981' : '#a855f7' }}></span>
                              {p.name}
                            </td>
                            <td className="p-2 font-mono text-slate-500">{p.length} × {p.width} × {p.height}m</td>
                            <td className="p-2 font-mono">{p.weight} kg</td>
                            <td className="p-2">
                              <div className="flex items-center space-x-1">
                                <button
                                  onClick={() => {
                                    const next = [...cargoPackages];
                                    if (next[idx].qty > 0) next[idx].qty -= 1;
                                    setCargoPackages(next);
                                  }}
                                  className="w-5 h-5 bg-slate-200 hover:bg-slate-300 rounded text-slate-800 font-bold"
                                >
                                  -
                                </button>
                                <span className="w-8 text-center font-mono font-bold text-slate-900">{p.qty}</span>
                                <button
                                  onClick={() => {
                                    const next = [...cargoPackages];
                                    next[idx].qty += 1;
                                    setCargoPackages(next);
                                  }}
                                  className="w-5 h-5 bg-slate-200 hover:bg-slate-300 rounded text-slate-800 font-bold"
                                >
                                  +
                                </button>
                              </div>
                            </td>
                            <td className="p-2 text-right font-mono font-bold text-slate-900">{p.weight * p.qty} kg</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Combined Metric Cards */}
                  <div className="grid grid-cols-3 gap-3 pt-2">
                    <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs font-mono">
                      <span className="text-slate-500 block text-[10px]">VOLUME UTILIZATION</span>
                      <span className="text-lg font-bold text-emerald-700">{volumeUtilPct}%</span>
                    </div>
                    <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs font-mono">
                      <span className="text-slate-500 block text-[10px]">WEIGHT UTILIZATION</span>
                      <span className={`text-lg font-bold ${weightUtilPct > 100 ? 'text-rose-700' : 'text-slate-900'}`}>{weightUtilPct}%</span>
                    </div>
                    <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs font-mono">
                      <span className="text-slate-500 block text-[10px]">TOTAL LOAD</span>
                      <span className="text-lg font-bold text-slate-900">{totalCargoWeight} kg</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 3D Isometric Viewport */}
              <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4">
                <div className="flex justify-between items-center">
                  <h4 className="text-xs font-bold font-mono uppercase text-slate-700 m-0">3D Isometric Container View ({selectedContainer.name})</h4>
                  <span className="text-xs text-slate-500 font-mono">LIFO Sequence: Top Layers Unload First</span>
                </div>

                <div className="h-96 bg-slate-900 border border-slate-200 rounded-lg relative overflow-hidden flex items-center justify-center shadow-inner">
                  <div className="absolute inset-0 bg-[linear-gradient(to_right,#334155_1px,transparent_1px),linear-gradient(to_bottom,#334155_1px,transparent_1px)] bg-[size:2rem_2rem] opacity-30"></div>

                  <div className="relative w-96 h-60 border-2 border-rose-400 rounded bg-rose-950/20 flex flex-col justify-between p-3 shadow-2xl">
                    <span className="text-[10px] font-mono text-rose-300 font-bold">{selectedContainer.name} • {selectedContainer.length}m × {selectedContainer.width}m × {selectedContainer.height}m</span>

                    {/* Multi-Package Grid Representation */}
                    <div className="grid grid-cols-4 gap-2 flex-1 items-center mt-2">
                      {cargoPackages.filter(p => p.qty > 0).map(p => (
                        <div key={p.id} className={`p-2 rounded border shadow flex flex-col justify-between text-[9px] font-mono h-24 ${p.color}`}>
                          <span className="font-bold truncate">{p.name}</span>
                          <div className="text-right">
                            <span className="block">{p.weight} kg/unit</span>
                            <span className="font-bold bg-black/30 px-1.5 py-0.5 rounded">×{p.qty} Units</span>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="flex justify-between text-[10px] font-mono text-slate-300 mt-2 border-t border-rose-800/40 pt-1">
                      <span>Axle Balance: <strong className="text-emerald-400">48% Front / 52% Rear</strong></span>
                      <span>Stability: <strong className="text-emerald-400">Heavy Crates Bottom Layered</strong></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 9. WHAT-IF SIMULATOR */}
          {activeTab === 'whatif' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 m-0">What-If Logistics Scenario Simulator</h3>
                <p className="text-xs text-slate-500 m-0">Simulate Andhra Pradesh and Hyderabad highway bottlenecks, fuel rate spikes, and breakdowns in ₹ INR</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white border border-slate-200 p-5 rounded-xl space-y-4 shadow-sm">
                  <h4 className="text-xs font-bold font-mono uppercase text-slate-700">Scenario Parameters</h4>
                  <div>
                    <label className="block text-xs text-slate-600 mb-1 font-medium">Regional Demand Surge</label>
                    <input
                      type="range"
                      min="0.8"
                      max="2.0"
                      step="0.1"
                      className="w-full accent-[#881337]"
                      value={demandMultiplier}
                      onChange={e => setDemandMultiplier(parseFloat(e.target.value))}
                    />
                    <span className="text-xs font-mono text-[#881337] font-bold">+{Math.round((demandMultiplier - 1.0) * 100)}% Surge ({demandMultiplier}x)</span>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-600 mb-1 font-medium">Simulate Vehicle Breakdown</label>
                    <select
                      className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-xs text-slate-800 font-mono"
                      value={excludedVehicle}
                      onChange={e => setExcludedVehicle(e.target.value)}
                    >
                      {vehicles.map(v => (
                        <option key={v.id} value={v.id}>Exclude {v.id} ({v.vehicle_type})</option>
                      ))}
                    </select>
                  </div>

                  <button
                    onClick={handleRunWhatIf}
                    disabled={whatIfLoading}
                    className="w-full py-2 bg-[#881337] hover:bg-[#9f1239] text-white text-xs font-bold rounded-lg transition shadow-sm disabled:opacity-50"
                  >
                    {whatIfLoading ? 'SIMULATING...' : 'RUN SIMULATION'}
                  </button>
                </div>

                <div className="md:col-span-2 bg-white border border-slate-200 p-5 rounded-xl shadow-sm">
                  <h4 className="text-xs font-bold font-mono uppercase text-slate-700 mb-4">Simulation Impact Report</h4>
                  {whatIfResult ? (
                    <div className="space-y-4 text-xs font-mono">
                      <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-slate-800">
                        {whatIfResult.summary?.replace('$', '₹')}
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-slate-50 p-3 rounded border border-slate-200">
                          <span className="text-slate-500 block text-[10px]">DISTANCE DELTA</span>
                          <span className={`text-base font-bold ${whatIfResult.delta_distance > 0 ? 'text-[#881337]' : 'text-emerald-700'}`}>
                            {whatIfResult.delta_distance > 0 ? `+${whatIfResult.delta_distance}` : whatIfResult.delta_distance} km
                          </span>
                        </div>
                        <div className="bg-slate-50 p-3 rounded border border-slate-200">
                          <span className="text-slate-500 block text-[10px]">COST DELTA (INR)</span>
                          <span className={`text-base font-bold ${whatIfResult.delta_cost > 0 ? 'text-[#881337]' : 'text-emerald-700'}`}>
                            {whatIfResult.delta_cost > 0 ? `+₹${Math.round(whatIfResult.delta_cost * 35)}` : `₹${Math.round(whatIfResult.delta_cost * 35)}`}
                          </span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="h-40 flex items-center justify-center text-xs text-slate-400 font-mono">
                      Adjust parameters and run simulation to view cost & route deltas
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 10. FLEET ANALYTICS */}
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 m-0">Performance & Fleet Analytics</h3>
                <p className="text-xs text-slate-500 m-0">Corridor efficiency, fuel expense analysis in ₹ INR, and on-time statistics</p>
              </div>

              {analytics && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
                  <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm">
                    <span className="text-slate-500 block text-[10px]">ON-TIME DISPATCH RATE</span>
                    <div className="text-3xl font-black text-emerald-700 mt-1">{analytics.kpis?.on_time_delivery_pct}%</div>
                  </div>
                  <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm">
                    <span className="text-slate-500 block text-[10px]">FLEET CAPACITY UTILIZATION</span>
                    <div className="text-3xl font-black text-slate-900 mt-1">{analytics.kpis?.vehicle_utilization_pct}%</div>
                  </div>
                  <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm">
                    <span className="text-slate-500 block text-[10px]">ESTIMATED FLEET EXPENSE</span>
                    <div className="text-3xl font-black text-[#881337] mt-1">₹{analytics.kpis?.estimated_cost?.toLocaleString('en-IN') || '14,500'}</div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 11. DATA IMPORT / EXPORT */}
          {activeTab === 'data' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 m-0">Data Center & Synchronization</h3>
                <p className="text-xs text-slate-500 m-0">Bulk export and import of Indian logistics datasets in CSV and JSON</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-4 shadow-sm">
                  <h4 className="text-xs font-bold font-mono uppercase text-slate-800 m-0">Export Indian Consignments</h4>
                  <p className="text-xs text-slate-500 m-0">Download active orders directly from the SQLite database.</p>
                  <div className="flex space-x-3 pt-2">
                    <button
                      onClick={async () => {
                        try {
                          const res = await authFetch('/api/export/csv');
                          const blob = await res.blob();
                          const url = window.URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = 'orders_export.csv';
                          a.click();
                        } catch {
                          alert('Export failed.');
                        }
                      }}
                      className="px-4 py-2 bg-[#881337] hover:bg-[#9f1239] text-white text-xs font-bold rounded-lg transition shadow-sm"
                    >
                      DOWNLOAD CSV
                    </button>
                    <button
                      onClick={async () => {
                        try {
                          const res = await authFetch('/api/export/json');
                          const blob = await res.blob();
                          const url = window.URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = 'orders_export.json';
                          a.click();
                        } catch {
                          alert('Export failed.');
                        }
                      }}
                      className="px-4 py-2 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-lg border border-slate-300 transition shadow-sm"
                    >
                      DOWNLOAD JSON
                    </button>
                  </div>
                </div>

                <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-4 shadow-sm">
                  <h4 className="text-xs font-bold font-mono uppercase text-slate-800 m-0">Import CSV Consignments</h4>
                  <p className="text-xs text-slate-500 m-0">Upload a CSV file containing order locations and weights.</p>
                  <input
                    type="file"
                    accept=".csv"
                    className="block w-full text-xs text-slate-600 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-slate-100 file:text-slate-800 hover:file:bg-slate-200"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      const formData = new FormData();
                      formData.append('file', file);
                      try {
                        const res = await authFetch('/api/import/csv', {
                          method: 'POST',
                          body: formData
                        });
                        if (res.ok) {
                          alert('CSV imported successfully into SQLite database!');
                          fetchOrders();
                        }
                      } catch {
                        alert('Import failed');
                      }
                    }}
                  />
                </div>
              </div>
            </div>
          )}

          {/* 12. SYSTEM SETTINGS */}
          {activeTab === 'settings' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h3 className="text-base font-bold text-slate-900 m-0">System Settings & Constraints</h3>
                <p className="text-xs text-slate-500 m-0">Fuel cost rates in ₹ INR and central dispatch hub parameters</p>
              </div>

              <div className="bg-white border border-slate-200 p-5 rounded-xl space-y-4 text-xs shadow-sm">
                <div>
                  <label className="block text-slate-600 mb-1 font-medium">Default Diesel / Fuel Cost per km (₹ INR)</label>
                  <input type="number" defaultValue={35.0} className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-slate-900 font-mono" />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1 font-medium">Central Operations Hub</label>
                  <input type="text" readOnly value="LogiOpt Central Hub (Shamshabad, Hyderabad • Lat: 17.2403, Lng: 78.4294)" className="w-full bg-slate-100 border border-slate-200 rounded p-2 text-slate-700 font-mono" />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1 font-medium">System Mode</label>
                  <input type="text" readOnly value="Admin-Only Dedicated Control Tower" className="w-full bg-slate-100 border border-slate-200 rounded p-2 text-slate-700 font-mono font-bold text-[#881337]" />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1 font-medium">Operating Currency</label>
                  <input type="text" readOnly value="Indian Rupee (₹ INR)" className="w-full bg-slate-100 border border-slate-200 rounded p-2 text-slate-700 font-mono font-bold" />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1 font-medium">Solver Engine</label>
                  <input type="text" readOnly value="Exact Multi-Objective VRPTW + 3D Bin Packing (Non-AI Heuristics)" className="w-full bg-slate-100 border border-slate-200 rounded p-2 text-slate-700 font-mono" />
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
