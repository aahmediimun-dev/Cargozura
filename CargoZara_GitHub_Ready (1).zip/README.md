# LoadNex AI — Intelligent Routing & 3D Cargo Optimization System

> **Tagline:** "Intelligent Routing & 3D Cargo Optimization System"

**LoadNex AI** is an enterprise-grade logistics decision-support platform designed for non-technical logistics planners, operations researchers, and research labs. It integrates **Vehicle Routing Problem with Time Windows (VRPTW)**, **3D Bin Packing Problem (3DBP)**, Pick-Drop-Return operations, driver assignment, an LLM-powered natural language logistics assistant (Gemini), What-If scenario simulation, and interactive 3D cargo visualization.

---

## 🌐 Localhost URLs

- **Main Website (Frontend)**: [http://localhost:5173](http://localhost:5173)
- **Backend API Base**: [http://localhost:8000](http://localhost:8000)
- **FastAPI Interactive Docs**: [http://localhost:8000/docs](http://localhost:8000/docs)
- **Health Check Endpoint**: [http://localhost:8000/health](http://localhost:8000/health)

---

## 🚀 Quick Start Guide (Windows)

### 1. Backend Startup
```powershell
cd backend

# 1. Create Virtual Environment (if not already created)
python -m venv venv

# 2. Activate Virtual Environment
.\venv\Scripts\activate

# 3. Install Dependencies
pip install -r requirements.txt

# 4. Start FastAPI Server
uvicorn app.main:app --reload --port 8000
```
- API Base: `http://localhost:8000`
- Health Check: `http://localhost:8000/health` (Returns `{"status": "ok"}`)
- API Documentation: `http://localhost:8000/docs`

---

### 2. Frontend Startup
```powershell
cd frontend

# 1. Install Node Dependencies
npm install

# 2. Start Vite Development Server
npm run dev
```
- Web Application: `http://localhost:5173`

---

## ⚙️ Environment Configuration

Copy the example env files and fill in your own values — **do not reuse the
placeholders below in a real deployment**:

```powershell
copy backend\.env.example backend\.env
copy frontend\.env.example frontend\.env
```

### Backend `.env` (see `backend/.env.example`):
```ini
DATABASE_URL=sqlite:///./loadnex.db
# PostgreSQL Example: DATABASE_URL=postgresql://user:password@localhost:5432/loadnex_db
GEMINI_API_KEY=your_gemini_api_key_here

# Required — no default is shipped in code:
JWT_SECRET_KEY=generate_with_secrets.token_hex(32)
ADMIN_USERNAME=admin
ADMIN_PASSWORD_HASH=generate_with_hash_password_helper

CORS_ORIGINS=http://localhost:5173,http://127.0.0.1:5173
PORT=8000
```

Generate the two required auth values:
```bash
python -c "import secrets; print(secrets.token_hex(32))"                       # JWT_SECRET_KEY
python -c "from app.api.auth import hash_password; print(hash_password('your-password'))"  # ADMIN_PASSWORD_HASH
```

### Frontend `.env` (see `frontend/.env.example`):
```ini
VITE_API_URL=http://localhost:8000/api
```

---

## 🌟 Core Modules Verified

1. **Dashboard (`/dashboard`)**: LoadNex AI control tower with 8 KPI cards, activity feed, performance charts, and Leaflet route overview map.
2. **Orders (`/orders`)**: Order management for pickup/drop/return operations with input validation.
3. **Vehicles (`/vehicles`)**: Fleet capacity meters, dimensions, fuel types, and driver assignments.
4. **Drivers (`/drivers`)**: Shift schedules, license verification, and vehicle compatibility.
5. **Routes (`/routes`)**: Stop sequence timelines, arrival/departure schedules, and cost breakdowns.
6. **VRPTW Solver (`/optimization`)**: Multi-objective VRPTW solver (*Minimize Distance, Cost, Delay, Vehicles, Maximize Utilization*).
7. **3D Loading Studio (`/loading`)**: Three.js / React Three Fiber interactive viewport displaying truck container chassis, color-coded 3D cargo boxes, and LIFO sequence indicators.
8. **LoadNex AI Chatbot (`/ai-assistant`)**: Natural language assistant powered by Gemini API function calling (`optimize_vrptw`, `optimize_bin_packing`, `run_what_if`) with constraint conflict guardrail warnings.
9. **What-If Simulator (`/what-if`)**: Scenario analysis comparing base vs modified parameters (vehicle breakdowns, demand surges).
10. **Analytics (`/analytics`)**: Fill rates, daily performance trends, and cost comparison charts.
11. **Data Center (`/data`)**: CSV & JSON bulk import/export center.
12. **Settings (`/settings`)**: Solver configuration, Gemini API key manager, and database architecture info.

---

## 🔐 Security & Guardrails
- **Authentication**: HMAC-SHA256 bearer tokens at `/api/auth/login`. `JWT_SECRET_KEY` and `ADMIN_PASSWORD_HASH` **must** be set in `backend/.env` — there is no hardcoded fallback secret or backdoor password in the shipped code.
- **Security Headers**: `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `X-XSS-Protection: 1; mode=block`, `Strict-Transport-Security`.
- **CORS**: configurable via `CORS_ORIGINS` in `backend/.env`; defaults to localhost dev origins only.
- **AI Safety**: Function tool allowlist preventing arbitrary code or database query execution.
- **Contradiction Detection**: Alerts planners if requested time constraints conflict with registered order time windows.
- **Secrets hygiene**: `.env` files and local `*.db` files are gitignored — never commit them. Only `.env.example` files are tracked.

---

## 🧪 Testing & Verification
```powershell
cd backend
python -m pytest tests/
```
- **Pytest Output**: `8/8 Passed` (100% pass rate across API, VRPTW, and 3D Bin Packing tests).
