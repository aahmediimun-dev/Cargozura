@echo off
echo ===================================================
echo     LoadNex AI - Unified Application Launcher
echo ===================================================

echo Starting Backend API (Port 8000)...
start "LoadNex Backend" /min cmd /c "cd /d %~dp0backend && venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000"

echo Starting Frontend UI (Port 5173)...
start "LoadNex Frontend" /min cmd /c "cd /d %~dp0frontend && npm run dev"

echo.
echo Launching LoadNex AI in your default browser...
timeout /t 3 >nul
start http://localhost:5173

echo.
echo LoadNex AI is running at: http://localhost:5173
