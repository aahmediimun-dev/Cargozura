# Modular 3D Bin Packing Solver Export Module
from backend.app.optimization.bin3d_solver import Bin3DSolver

__all__ = ["Bin3DSolver"]
