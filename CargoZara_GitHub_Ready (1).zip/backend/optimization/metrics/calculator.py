from typing import List, Dict, Any

def calculate_kpi_summary(routes: List[Any]) -> Dict[str, float]:
    total_dist = sum(getattr(r, "total_distance", 0.0) for r in routes)
    total_cost = sum(getattr(r, "cost", 0.0) for r in routes)
    total_late = sum(getattr(r, "late_deliveries", 0) for r in routes)
    return {
        "total_distance_km": round(total_dist, 2),
        "total_cost": round(total_cost, 2),
        "total_late_deliveries": total_late
    }
