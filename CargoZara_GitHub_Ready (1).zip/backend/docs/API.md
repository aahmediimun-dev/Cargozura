# REST API Endpoint Documentation — LogiOpt AI

## Base URL
`/api`

## Core Endpoints

### 1. Orders Management
- `GET /api/orders`: List all delivery orders.
- `POST /api/orders`: Create a new order.
- `PUT /api/orders/{id}`: Update existing order details.
- `DELETE /api/orders/{id}`: Delete an order.

### 2. Vehicle Fleet
- `GET /api/vehicles`: List vehicle fleet and availability status.
- `POST /api/vehicles`: Add vehicle.

### 3. Drivers
- `GET /api/drivers`: List driver roster and shift schedules.

### 4. Optimization Engine
- `POST /api/optimize/vrptw`: Run VRPTW routing solver with objective function (`minimize_distance`, `minimize_cost`, `minimize_delay`, `minimize_vehicles`).
- `POST /api/optimize/bin-packing`: Run 3D Bin Packing solver with container dimensions and package list.
- `POST /api/optimize/integrated`: Run integrated VRPTW + 3D Bin Packing sequence-aware solver.

### 5. What-If Simulator
- `POST /api/what-if`: Simulate fleet breakdowns, demand multipliers, and order cancellations.

### 6. AI Assistant
- `POST /api/ai/chat`: Interact with LogiOpt AI assistant. Triggers function calling & guardrails verification.

### 7. Import & Export
- `GET /api/export/csv`: Export orders to CSV.
- `GET /api/export/json`: Export orders to JSON.
- `POST /api/import/csv`: Import orders from CSV upload.
