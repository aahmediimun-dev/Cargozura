# Optimization Algorithms Formulation — LogiOpt AI

## 1. Vehicle Routing Problem with Time Windows (VRPTW)

### Problem Formulation
Given:
- Depot $D$ at $(lat_0, lon_0)$ with operating window $[T_0^{start}, T_0^{end}]$.
- Set of customer orders $C = \{1, \dots, n\}$, where order $i$ has location $(lat_i, lon_i)$, weight demand $w_i$, volume demand $v_i$, service time $s_i$, and delivery time window $[a_i, b_i]$.
- Fleet of available vehicles $V = \{1, \dots, m\}$, each with maximum weight capacity $W_k$ and volume capacity $V_k$.

### Objective Functions
1. **Minimize Distance**:
   $$\min \sum_{k \in V} \sum_{i, j \in C \cup \{D\}} d_{ij} x_{ijk}$$
2. **Minimize Cost**:
   $$\min \sum_{k \in V} c_k \cdot \text{Distance}_k$$
3. **Minimize Delivery Delay**:
   $$\min \sum_{i \in C} \max(0, \text{Arrival}_i - b_i)$$

---

## 2. 3D Bin Packing Problem (3DBP)

### Formulation
Given container dimensions $(L, W, H)$ and weight capacity $W_{max}$, place items $i \in I$ with dimensions $(l_i, w_i, h_i)$ and weight $w_i$ such that:
1. No item exceeds container boundary: $x_i + dx_i \le L$, $y_i + dy_i \le W$, $z_i + dz_i \le H$.
2. No 3D box overlap between items $i$ and $j$.
3. Sequence Awareness: Packages for earlier stops are loaded last (or placed near doors) for LIFO accessibility.
