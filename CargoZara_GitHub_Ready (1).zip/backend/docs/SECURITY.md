# Security Specification — LogiOpt AI

## 1. Authentication & Authorization
- **HMAC-SHA256 Token Authentication**: User credentials are validated at `/api/auth/login` and issued a signed bearer token.
- **Password Protection**: Passwords are never stored in plain text.
- **Role-Based Access Control**: Supports `Admin`, `Planner`, and `Field Staff` roles.

## 2. API & Network Security
- **Security Headers**: All API responses enforce `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `X-XSS-Protection: 1; mode=block`, and `Strict-Transport-Security`.
- **CORS Configuration**: Restricts origin domain access to authorized clients.
- **Environment Isolation**: Gemini API keys and secrets remain strictly server-side in `.env` files and are never sent to Vite/React client builds.

## 3. AI Safety & Guardrails
- **Function Allowlist**: Gemini assistant can only invoke pre-approved solver tools (`optimize_vrptw`, `optimize_bin_packing`, `run_what_if`).
- **Prompt Injection Defense**: Input prompts are sanitized before being passed to LLM services.
- **Contradiction Detection**: Alerts planners if requested time constraints conflict with registered order windows.
