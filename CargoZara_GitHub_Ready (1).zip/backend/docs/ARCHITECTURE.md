# System Architecture Specification — LogiOpt AI

## 1. High-Level Architecture

LogiOpt AI utilizes a decoupled client-server architecture:

- **Client Layer**: React 18 single-page app (SPA) bundled with Vite. Renders interactive Three.js 3D vehicle loading viewports, Leaflet maps, and Recharts analytical dashboards.
- **Backend Service Layer**: FastAPI Python application providing RESTful JSON endpoints.
- **Optimization Layer**: Modular Python solver engines decoupling problem generation, constraint verification, and mathematical heuristic resolution.
- **AI Assistant Layer**: Google GenAI / Gemini API client configured with Function Tool Calling and guardrails validation.
- **Database Layer**: SQLAlchemy 2.0 ORM backed by SQLite for local development and PostgreSQL / Apache CouchDB NoSQL for production scale.

```
+-------------------------------------------------------+
|                React 18 SPA (Vite + TS)              |
|   Dashboard | 3D Loading Canvas | Map | AI Chat UI   |
+-------------------------------------------------------+
                           | REST API
+-------------------------------------------------------+
|                   FastAPI Backend                     |
|  /api/orders | /api/vehicles | /api/optimize | /ai    |
+-------------------------------------------------------+
        |                  |                    |
+---------------+  +---------------+  +-----------------+
| VRPTW Solver  |  | 3DBP Solver   |  | Gemini AI Engine|
+---------------+  +---------------+  +-----------------+
```
