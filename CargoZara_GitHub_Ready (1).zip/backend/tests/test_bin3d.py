from app.optimization.bin3d_solver import Bin3DSolver
from app.schemas.payload import PackageSchema

def test_bin3d_packing():
    solver = Bin3DSolver(container_length=6.0, container_width=2.4, container_height=2.4, max_weight=4500.0)
    packages = [
        PackageSchema(id="P1", length=1.0, width=1.0, height=1.0, weight=200.0, delivery_stop=1),
        PackageSchema(id="P2", length=1.2, width=0.8, height=0.9, weight=150.0, delivery_stop=2)
    ]
    res = solver.pack(packages)
    assert res.packages_loaded == 2
    assert res.volume_utilization > 0.0
    assert len(res.items) == 2
