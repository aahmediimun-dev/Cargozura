from app.seed_data import DEMO_ORDERS, DEMO_VEHICLES, DEMO_DRIVERS, DEMO_DEPOT
from app.optimization.vrptw_solver import VRPTWSolver

def test_vrptw_solver_basic():
    solver = VRPTWSolver(DEMO_ORDERS, DEMO_VEHICLES, DEMO_DRIVERS, DEMO_DEPOT, "minimize_distance")
    result = solver.solve()
    assert result.status in ["feasible", "heuristic_solution"]
    assert result.vehicles_used > 0
    assert result.total_distance > 0.0
    assert len(result.routes) > 0

def test_vrptw_capacity_constraints():
    solver = VRPTWSolver(DEMO_ORDERS, DEMO_VEHICLES, DEMO_DRIVERS, DEMO_DEPOT, "minimize_distance")
    result = solver.solve()
    for route in result.routes:
        assert route.total_weight <= 8000.0  # max fleet cap
