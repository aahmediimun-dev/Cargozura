from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def get_admin_token():
    res = client.post("/api/auth/login", json={"username": "admin", "password": "admin123"})
    assert res.status_code == 200
    return res.json()["access_token"]

def test_root_endpoint():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["status"] == "online"
    assert response.json()["mode"] == "Admin-Only System"

def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert "Admin-Only" in response.json()["security"]

def test_auth_login_success():
    response = client.post("/api/auth/login", json={"username": "admin", "password": "admin123"})
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"
    assert data["username"] == "admin"
    assert data["role"] == "Administrator"

def test_auth_login_invalid_credentials():
    response = client.post("/api/auth/login", json={"username": "admin", "password": "wrongpassword"})
    assert response.status_code == 401
    assert "Invalid administrator credentials" in response.json()["detail"]

def test_unauthenticated_access_blocked():
    # Without token, all resource endpoints must return 401
    res_orders = client.get("/api/orders")
    assert res_orders.status_code == 401
    assert "Admin access only" in res_orders.json()["detail"]

    res_vehicles = client.get("/api/vehicles")
    assert res_vehicles.status_code == 401

    res_drivers = client.get("/api/drivers")
    assert res_drivers.status_code == 401

    res_opt = client.post("/api/optimize/vrptw", json={"objective": "minimize_distance"})
    assert res_opt.status_code == 401

def test_invalid_token_blocked():
    headers = {"Authorization": "Bearer bogus_invalid_token"}
    response = client.get("/api/orders", headers=headers)
    assert response.status_code == 401

def test_authenticated_get_orders():
    token = get_admin_token()
    headers = {"Authorization": f"Bearer {token}"}
    response = client.get("/api/orders", headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    assert len(response.json()) >= 10

def test_authenticated_get_vehicles():
    token = get_admin_token()
    headers = {"Authorization": f"Bearer {token}"}
    response = client.get("/api/vehicles", headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), list)

def test_authenticated_get_drivers():
    token = get_admin_token()
    headers = {"Authorization": f"Bearer {token}"}
    response = client.get("/api/drivers", headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), list)

def test_authenticated_verify_session():
    token = get_admin_token()
    headers = {"Authorization": f"Bearer {token}"}
    response = client.get("/api/auth/verify", headers=headers)
    assert response.status_code == 200
    assert response.json()["status"] == "valid"
    assert response.json()["username"] == "admin"
