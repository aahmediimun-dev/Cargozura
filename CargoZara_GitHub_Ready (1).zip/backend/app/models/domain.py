from sqlalchemy import Column, String, Float, Integer, Boolean, DateTime, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
from ..database import Base

class OrderModel(Base):
    __tablename__ = "orders"

    id = Column(String, primary_key=True, index=True)
    customer_name = Column(String, nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    demand_weight = Column(Float, nullable=False)  # in kg
    package_volume = Column(Float, nullable=False) # in m3
    delivery_type = Column(String, default="drop")  # pickup, drop, return
    time_window_start = Column(String, nullable=False)  # HH:MM format e.g. "09:00"
    time_window_end = Column(String, nullable=False)    # HH:MM format e.g. "17:00"
    service_time = Column(Integer, default=15)          # in minutes
    priority = Column(String, default="normal")        # low, normal, high, urgent
    fragile = Column(Boolean, default=False)
    stackable = Column(Boolean, default=True)
    vehicle_requirement = Column(String, nullable=True) # e.g. "truck", "van"
    status = Column(String, default="pending")          # pending, assigned, delivered, cancelled
    created_at = Column(DateTime, default=datetime.utcnow)

class VehicleModel(Base):
    __tablename__ = "vehicles"

    id = Column(String, primary_key=True, index=True)
    vehicle_type = Column(String, nullable=False)  # Van, Truck, Mini Truck, Large Truck
    max_weight_capacity = Column(Float, nullable=False)  # in kg
    length = Column(Float, nullable=False)               # in meters
    width = Column(Float, nullable=False)                # in meters
    height = Column(Float, nullable=False)               # in meters
    volume_capacity = Column(Float, nullable=False)      # in m3 (length * width * height)
    fuel_type = Column(String, default="Diesel")
    cost_per_km = Column(Float, default=12.5)
    availability = Column(Boolean, default=True)
    current_location = Column(String, default="Depot Main")
    driver_assigned = Column(String, nullable=True)
    status = Column(String, default="available")  # available, in_transit, maintenance

class DriverModel(Base):
    __tablename__ = "drivers"

    id = Column(String, primary_key=True, index=True)
    name = Column(String, nullable=False)
    availability = Column(Boolean, default=True)
    shift_start = Column(String, default="08:00")
    shift_end = Column(String, default=17, nullable=True)  # "17:00"
    license_type = Column(String, default="Heavy Commercial")
    vehicle_compatibility = Column(String, default="All")
    max_working_hours = Column(Float, default=8.0)
    current_assignment = Column(String, nullable=True)
    status = Column(String, default="active")  # active, on_break, off_duty

class PackageModel(Base):
    __tablename__ = "packages"

    id = Column(String, primary_key=True, index=True)
    order_id = Column(String, ForeignKey("orders.id"), nullable=True)
    length = Column(Float, nullable=False)  # in meters
    width = Column(Float, nullable=False)   # in meters
    height = Column(Float, nullable=False)  # in meters
    weight = Column(Float, nullable=False)  # in kg
    fragile = Column(Boolean, default=False)
    stackable = Column(Boolean, default=True)
    priority = Column(String, default="normal")
    delivery_stop = Column(Integer, default=1)

class OptimizationRunModel(Base):
    __tablename__ = "optimization_runs"

    id = Column(String, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    run_type = Column(String, default="vrptw_3dbp")  # vrptw, 3dbp, integrated
    objective = Column(String, default="minimize_distance")
    status = Column(String, default="completed")     # feasible, heuristic, optimal, failed
    vehicles_used = Column(Integer, default=0)
    total_distance = Column(Float, default=0.0)
    total_cost = Column(Float, default=0.0)
    on_time_rate = Column(Float, default=100.0)
    volume_utilization = Column(Float, default=0.0)
    weight_utilization = Column(Float, default=0.0)
    routes_json = Column(JSON, nullable=True)
    loading_plan_json = Column(JSON, nullable=True)

class ScenarioModel(Base):
    __tablename__ = "scenarios"

    id = Column(String, primary_key=True, index=True)
    name = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    modified_parameters = Column(JSON, nullable=False)
    results_json = Column(JSON, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class ChatSessionModel(Base):
    __tablename__ = "chat_sessions"

    id = Column(String, primary_key=True, index=True)
    messages = Column(JSON, default=list)
    created_at = Column(DateTime, default=datetime.utcnow)
