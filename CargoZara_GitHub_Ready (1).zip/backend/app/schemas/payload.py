from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class OrderSchema(BaseModel):
    id: str
    customer_name: str
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    demand_weight: float = Field(..., gt=0, description="Demand weight in kg")
    package_volume: float = Field(..., gt=0, description="Volume in m3")
    delivery_type: str = Field("drop", description="pickup, drop, return")
    time_window_start: str = Field("09:00", description="HH:MM format")
    time_window_end: str = Field("17:00", description="HH:MM format")
    service_time: int = Field(15, ge=0, description="Service time in minutes")
    priority: str = Field("normal", description="low, normal, high, urgent")
    fragile: bool = False
    stackable: bool = True
    vehicle_requirement: Optional[str] = None
    status: str = "pending"

class VehicleSchema(BaseModel):
    id: str
    vehicle_type: str
    max_weight_capacity: float = Field(..., gt=0)
    length: float = Field(..., gt=0)
    width: float = Field(..., gt=0)
    height: float = Field(..., gt=0)
    volume_capacity: float = Field(..., gt=0)
    fuel_type: str = "Diesel"
    cost_per_km: float = 12.5
    availability: bool = True
    current_location: str = "Depot Main"
    driver_assigned: Optional[str] = None
    status: str = "available"

class DriverSchema(BaseModel):
    id: str
    name: str
    availability: bool = True
    shift_start: str = "08:00"
    shift_end: str = "17:00"
    license_type: str = "Heavy Commercial"
    vehicle_compatibility: str = "All"
    max_working_hours: float = 8.0
    current_assignment: Optional[str] = None
    status: str = "active"

class PackageSchema(BaseModel):
    id: str
    order_id: Optional[str] = None
    length: float = Field(..., gt=0)
    width: float = Field(..., gt=0)
    height: float = Field(..., gt=0)
    weight: float = Field(..., gt=0)
    fragile: bool = False
    stackable: bool = True
    priority: str = "normal"
    delivery_stop: int = 1
    position: Optional[List[float]] = None  # [x, y, z]
    rotation: Optional[List[float]] = None  # [rx, ry, rz]

class DepotSchema(BaseModel):
    id: str = "DEPOT-01"
    name: str = "Central Logistics Hub"
    latitude: float = 19.0760
    longitude: float = 72.8777
    time_window_start: str = "08:00"
    time_window_end: str = "20:00"

class VrptwRequest(BaseModel):
    orders: Optional[List[OrderSchema]] = None
    vehicles: Optional[List[VehicleSchema]] = None
    drivers: Optional[List[DriverSchema]] = None
    depot: Optional[DepotSchema] = None
    objective: str = Field("minimize_distance", description="minimize_distance, minimize_cost, minimize_delay, minimize_vehicles, maximize_utilization")
    allow_overtime: bool = False

class RouteStop(BaseModel):
    sequence: int
    order_id: str
    customer_name: str
    arrival_time: str
    departure_time: str
    distance_from_prev: float
    travel_time_min: float
    load_weight: float
    load_volume: float
    delivery_type: str
    late_minutes: float = 0.0

class VehicleRoute(BaseModel):
    vehicle_id: str
    driver_id: Optional[str] = None
    stops: List[RouteStop]
    total_distance: float
    total_travel_time: float
    total_weight: float
    total_volume: float
    weight_utilization: float
    volume_utilization: float
    cost: float
    status: str = "feasible"
    late_deliveries: int = 0

class VrptwResult(BaseModel):
    status: str  # feasible, heuristic_solution, exact_optimal, infeasible
    objective: str
    vehicles_used: int
    routes: List[VehicleRoute]
    total_distance: float
    total_cost: float
    total_travel_time: float
    on_time_rate: float
    weight_utilization: float
    volume_utilization: float
    late_deliveries: int
    constraint_violations: List[str] = []
    message: str

class BinPackingRequest(BaseModel):
    vehicle_id: Optional[str] = None
    container_length: float
    container_width: float
    container_height: float
    max_weight: float
    packages: List[PackageSchema]

class PlacedItem(BaseModel):
    id: str
    order_id: Optional[str] = None
    length: float
    width: float
    height: float
    weight: float
    position: List[float]  # [x, y, z] coordinates of back-bottom-left corner
    rotation: List[float]  # [rx, ry, rz] in degrees
    delivery_stop: int
    color: Optional[str] = "#3B82F6"

class BinPackingResult(BaseModel):
    vehicle_id: str
    container_dimensions: Dict[str, float]
    volume_utilization: float
    weight_utilization: float
    packages_loaded: int
    packages_unloaded: int
    unused_volume: float
    loading_efficiency: float
    items: List[PlacedItem]
    unloaded_items: List[PackageSchema] = []
    stability_warnings: List[str] = []
    collision_warnings: List[str] = []

class WhatIfRequest(BaseModel):
    scenario_name: str
    description: Optional[str] = None
    modified_orders: Optional[List[OrderSchema]] = None
    modified_vehicles: Optional[List[VehicleSchema]] = None
    modified_drivers: Optional[List[DriverSchema]] = None
    objective: str = "minimize_distance"
    demand_multiplier: float = 1.0
    removed_vehicle_ids: List[str] = []
    removed_order_ids: List[str] = []

class WhatIfResult(BaseModel):
    scenario_name: str
    original_result: VrptwResult
    modified_result: VrptwResult
    delta_distance: float
    delta_cost: float
    delta_vehicles: int
    delta_on_time_rate: float
    summary: str

class AiChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = "default_session"

class AiChatResponse(BaseModel):
    reply: str
    session_id: str
    intent_detected: Optional[str] = None
    function_called: Optional[str] = None
    extracted_constraints: Optional[Dict[str, Any]] = None
    guardrail_warnings: List[str] = []
    structured_output: Optional[Dict[str, Any]] = None
