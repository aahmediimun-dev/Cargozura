import os
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .database import engine, Base
from .api import orders, vehicles, drivers, optimization, bin_packing, ai, what_if, analytics, import_export, auth
from .api.auth import verify_admin_token

# Initialize DB tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="LogiOpt Admin Dispatch & Optimization Control Tower API",
    version="2.1.0"
)

# Security Headers Middleware
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response

# Global Exception Handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    if isinstance(exc, HTTPException):
        return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail}, headers=getattr(exc, "headers", None))
    return JSONResponse(status_code=500, content={"detail": "An internal operational error occurred."})

# CORS origins: defaults cover local dev; add CORS_ORIGINS to your .env as a
# comma-separated list of allowed origins for a public/production deployment.
_default_origins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "http://localhost:8000",
    "http://127.0.0.1:8000",
]
_env_origins = os.getenv("CORS_ORIGINS", "")
origins = [o.strip() for o in _env_origins.split(",") if o.strip()] or _default_origins

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Auth Router (Public for login and token verification)
app.include_router(auth.router, prefix=settings.API_V1_STR)

# Protected Admin Routers (Strictly require valid Admin Bearer token)
admin_dep = [Depends(verify_admin_token)]
app.include_router(orders.router, prefix=settings.API_V1_STR, dependencies=admin_dep)
app.include_router(vehicles.router, prefix=settings.API_V1_STR, dependencies=admin_dep)
app.include_router(drivers.router, prefix=settings.API_V1_STR, dependencies=admin_dep)
app.include_router(optimization.router, prefix=settings.API_V1_STR, dependencies=admin_dep)
app.include_router(bin_packing.router, prefix=settings.API_V1_STR, dependencies=admin_dep)
app.include_router(ai.router, prefix=settings.API_V1_STR, dependencies=admin_dep)
app.include_router(what_if.router, prefix=settings.API_V1_STR, dependencies=admin_dep)
app.include_router(analytics.router, prefix=settings.API_V1_STR, dependencies=admin_dep)
app.include_router(import_export.router, prefix=settings.API_V1_STR, dependencies=admin_dep)

@app.get("/health")
def health_check():
    return {
        "status": "ok",
        "system": "LogiOpt Admin Control Tower",
        "security": "Admin-Only Mode Enforced"
    }

@app.get("/")
def root():
    return {
        "status": "online",
        "app_name": settings.PROJECT_NAME,
        "tagline": settings.TAGLINE,
        "mode": "Admin-Only System",
        "docs_url": "/docs",
        "health_url": "/health"
    }
