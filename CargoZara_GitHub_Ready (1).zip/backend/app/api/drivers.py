from fastapi import APIRouter, HTTPException
from typing import List
from ..schemas.payload import DriverSchema
from ..seed_data import DEMO_DRIVERS

router = APIRouter(prefix="/drivers", tags=["Drivers"])

drivers_db: List[DriverSchema] = list(DEMO_DRIVERS)

@router.get("", response_model=List[DriverSchema])
def get_drivers():
    return drivers_db

@router.post("", response_model=DriverSchema)
def create_driver(driver: DriverSchema):
    if any(d.id == driver.id for d in drivers_db):
        raise HTTPException(status_code=400, detail=f"Driver {driver.id} already exists.")
    drivers_db.append(driver)
    return driver

@router.put("/{driver_id}", response_model=DriverSchema)
def update_driver(driver_id: str, updated_driver: DriverSchema):
    for i, d in enumerate(drivers_db):
        if d.id == driver_id:
            drivers_db[i] = updated_driver
            return updated_driver
    raise HTTPException(status_code=404, detail="Driver not found")

@router.delete("/{driver_id}")
def delete_driver(driver_id: str):
    global drivers_db
    drivers_db = [d for d in drivers_db if d.id != driver_id]
    return {"message": f"Driver {driver_id} deleted successfully."}
