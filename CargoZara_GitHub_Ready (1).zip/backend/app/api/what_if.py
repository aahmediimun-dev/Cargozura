from fastapi import APIRouter
from ..schemas.payload import WhatIfRequest, WhatIfResult
from ..optimization.vrptw_solver import VRPTWSolver
from ..api.orders import orders_db
from ..api.vehicles import vehicles_db
from ..api.drivers import drivers_db
from ..seed_data import DEMO_DEPOT

router = APIRouter(prefix="/what-if", tags=["What-If Simulator"])

@router.post("", response_model=WhatIfResult)
def simulate_scenario(req: WhatIfRequest):
    # Base scenario
    base_solver = VRPTWSolver(orders_db, vehicles_db, drivers_db, DEMO_DEPOT, req.objective)
    orig_res = base_solver.solve()

    # Modified scenario data preparation
    mod_orders = [o for o in (req.modified_orders or orders_db) if o.id not in req.removed_order_ids]
    if req.demand_multiplier != 1.0:
        for o in mod_orders:
            o.demand_weight *= req.demand_multiplier

    mod_vehicles = [v for v in (req.modified_vehicles or vehicles_db) if v.id not in req.removed_vehicle_ids]
    mod_drivers = req.modified_drivers or drivers_db

    mod_solver = VRPTWSolver(mod_orders, mod_vehicles, mod_drivers, DEMO_DEPOT, req.objective)
    mod_res = mod_solver.solve()

    delta_dist = round(mod_res.total_distance - orig_res.total_distance, 2)
    delta_cost = round(mod_res.total_cost - orig_res.total_cost, 2)
    delta_vehs = mod_res.vehicles_used - orig_res.vehicles_used
    delta_on_time = round(mod_res.on_time_rate - orig_res.on_time_rate, 1)

    summary = (
        f"Scenario '{req.scenario_name}': Distance changed by {delta_dist:+} km, "
        f"cost changed by ${delta_cost:+}, vehicles used changed by {delta_vehs:+}, "
        f"and on-time delivery rate changed by {delta_on_time:+}%."
    )

    return WhatIfResult(
        scenario_name=req.scenario_name,
        original_result=orig_res,
        modified_result=mod_res,
        delta_distance=delta_dist,
        delta_cost=delta_cost,
        delta_vehicles=delta_vehs,
        delta_on_time_rate=delta_on_time,
        summary=summary
    )
