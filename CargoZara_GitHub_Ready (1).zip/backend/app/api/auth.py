import os
import hashlib
import hmac
import time
from fastapi import APIRouter, HTTPException, Depends, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

router = APIRouter(prefix="/auth", tags=["Admin Authentication"])
security = HTTPBearer(auto_error=False)

# JWT_SECRET_KEY must be set via environment variable (see .env.example).
# No hardcoded fallback: a shared default secret would let anyone forge
# valid admin tokens for every deployment running this code.
SECRET_KEY = os.getenv("JWT_SECRET_KEY")
if not SECRET_KEY:
    import secrets as _secrets
    SECRET_KEY = _secrets.token_hex(32)
    print(
        "WARNING: JWT_SECRET_KEY is not set. Generated a random secret for this "
        "process only (all sessions will be invalidated on restart). Set "
        "JWT_SECRET_KEY in your .env before deploying publicly."
    )

ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")

def hash_password(password: str, salt: bytes = None) -> str:
    if salt is None:
        salt = os.urandom(16)
    key = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 100000)
    return f"{salt.hex()}${key.hex()}"

def verify_password(plain_password: str, hashed: str) -> bool:
    try:
        salt_hex, key_hex = hashed.split("$")
        salt = bytes.fromhex(salt_hex)
        key = hashlib.pbkdf2_hmac("sha256", plain_password.encode("utf-8"), salt, 100000)
        return hmac.compare_digest(key.hex(), key_hex)
    except Exception:
        return False

# ADMIN_PASSWORD_HASH must be set via environment variable (see .env.example).
# Generate one with: python -c "from app.api.auth import hash_password; print(hash_password('your-password'))"
# No hardcoded default hash is shipped, so a public deployment can't be logged
# into with a password value taken straight from this source file.
ADMIN_PASSWORD_HASH = os.getenv("ADMIN_PASSWORD_HASH")
if not ADMIN_PASSWORD_HASH:
    print(
        "WARNING: ADMIN_PASSWORD_HASH is not set. /auth/login will reject all "
        "credentials until you set it in your .env (see backend/.env.example)."
    )

class LoginRequest(BaseModel):
    username: str
    password: str

class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    username: str
    role: str = "Administrator"

def generate_admin_token(username: str) -> str:
    timestamp = str(int(time.time()) + 86400)  # 24 hours validity
    payload = f"{username}:admin:{timestamp}"
    signature = hmac.new(SECRET_KEY.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"{payload}:{signature}"

def verify_admin_token(credentials: HTTPAuthorizationCredentials = Security(security)) -> dict:
    if not credentials or not credentials.credentials:
        raise HTTPException(
            status_code=401,
            detail="Authentication required. Admin access only.",
            headers={"WWW-Authenticate": "Bearer"}
        )
    token = credentials.credentials
    parts = token.split(":")
    if len(parts) != 4:
        raise HTTPException(
            status_code=401,
            detail="Invalid authentication token format.",
            headers={"WWW-Authenticate": "Bearer"}
        )
    username, role, timestamp, signature = parts
    try:
        exp = int(timestamp)
    except ValueError:
        raise HTTPException(
            status_code=401,
            detail="Invalid token timestamp.",
            headers={"WWW-Authenticate": "Bearer"}
        )
    
    if exp < time.time():
        raise HTTPException(
            status_code=401,
            detail="Admin session expired. Please log in again.",
            headers={"WWW-Authenticate": "Bearer"}
        )
    
    expected_sig = hmac.new(
        SECRET_KEY.encode("utf-8"),
        f"{username}:{role}:{timestamp}".encode("utf-8"),
        hashlib.sha256
    ).hexdigest()
    
    if not hmac.compare_digest(signature, expected_sig):
        raise HTTPException(
            status_code=401,
            detail="Invalid token signature. Unauthorized.",
            headers={"WWW-Authenticate": "Bearer"}
        )
    
    if username != ADMIN_USERNAME or role != "admin":
        raise HTTPException(
            status_code=403,
            detail="Access forbidden: Administrator privileges required."
        )
    
    return {"username": username, "role": "Administrator", "authenticated": True}

@router.post("/login", response_model=LoginResponse)
def login(req: LoginRequest):
    if (
        ADMIN_PASSWORD_HASH
        and req.username == ADMIN_USERNAME
        and verify_password(req.password, ADMIN_PASSWORD_HASH)
    ):
        token = generate_admin_token(ADMIN_USERNAME)
        return LoginResponse(access_token=token, token_type="bearer", username=ADMIN_USERNAME, role="Administrator")

    raise HTTPException(
        status_code=401,
        detail="Invalid administrator credentials. Access denied."
    )

@router.get("/verify")
def verify_session(admin=Depends(verify_admin_token)):
    return {"status": "valid", "username": admin["username"], "role": "Administrator"}

@router.post("/logout")
def logout(admin=Depends(verify_admin_token)):
    return {"message": "Admin successfully logged out."}
