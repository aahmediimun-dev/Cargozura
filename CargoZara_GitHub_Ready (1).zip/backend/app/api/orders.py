from fastapi import APIRouter, HTTPException, Depends
from typing import List
from ..schemas.payload import OrderSchema
from ..seed_data import DEMO_ORDERS

router = APIRouter(prefix="/orders", tags=["Orders"])

# In-memory store initialized with seed data for fast response & DB synchronization
orders_db: List[OrderSchema] = list(DEMO_ORDERS)

@router.get("", response_model=List[OrderSchema])
def get_orders():
    return orders_db

@router.post("", response_model=OrderSchema)
def create_order(order: OrderSchema):
    if any(o.id == order.id for o in orders_db):
        raise HTTPException(status_code=400, detail=f"Order {order.id} already exists.")
    orders_db.append(order)
    return order

@router.put("/{order_id}", response_model=OrderSchema)
def update_order(order_id: str, updated_order: OrderSchema):
    for i, o in enumerate(orders_db):
        if o.id == order_id:
            orders_db[i] = updated_order
            return updated_order
    raise HTTPException(status_code=404, detail="Order not found")

@router.patch("/{order_id}/status", response_model=OrderSchema)
def update_order_status(order_id: str, status: str):
    for i, o in enumerate(orders_db):
        if o.id == order_id:
            orders_db[i].status = status
            return orders_db[i]
    raise HTTPException(status_code=404, detail="Order not found")

@router.delete("/{order_id}")
def delete_order(order_id: str):
    global orders_db
    orders_db = [o for o in orders_db if o.id != order_id]
    return {"message": f"Order {order_id} deleted successfully."}
