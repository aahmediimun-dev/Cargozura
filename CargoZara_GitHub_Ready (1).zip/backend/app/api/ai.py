from fastapi import APIRouter
from ..schemas.payload import AiChatRequest, AiChatResponse
from ..ai.gemini_service import GeminiLogisticsAssistant
from ..api.orders import orders_db
from ..api.vehicles import vehicles_db
from ..api.drivers import drivers_db

router = APIRouter(prefix="/ai", tags=["AI Assistant"])

ai_assistant = GeminiLogisticsAssistant()

@router.post("/chat", response_model=AiChatResponse)
def chat_with_loadnex(req: AiChatRequest):
    orders_data = [o.model_dump() for o in orders_db]
    vehicles_data = [v.model_dump() for v in vehicles_db]
    drivers_data = [d.model_dump() for d in drivers_db]

    res = ai_assistant.process_message(
        message=req.message,
        orders=orders_data,
        vehicles=vehicles_data,
        drivers=drivers_data
    )

    return AiChatResponse(
        reply=res["reply"],
        session_id=req.session_id or "default",
        intent_detected=res["intent_detected"],
        function_called=res["function_called"],
        extracted_constraints=res["extracted_constraints"],
        guardrail_warnings=res["guardrail_warnings"],
        structured_output=res["structured_output"]
    )
