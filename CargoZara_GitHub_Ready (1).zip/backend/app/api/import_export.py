from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse
import io
import json
import csv
from typing import List, Dict, Any
from ..api.orders import orders_db
from ..schemas.payload import OrderSchema

router = APIRouter(tags=["Import / Export"])

@router.get("/export/csv")
def export_orders_csv():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "id", "customer_name", "latitude", "longitude", "demand_weight",
        "package_volume", "delivery_type", "time_window_start", "time_window_end",
        "service_time", "priority", "fragile", "stackable", "status"
    ])
    for o in orders_db:
        writer.writerow([
            o.id, o.customer_name, o.latitude, o.longitude, o.demand_weight,
            o.package_volume, o.delivery_type, o.time_window_start, o.time_window_end,
            o.service_time, o.priority, o.fragile, o.stackable, o.status
        ])
    output.seek(0)
    return StreamingResponse(
        io.BytesIO(output.getvalue().encode()),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=loadnex_orders.csv"}
    )

@router.get("/export/json")
def export_orders_json():
    data = [o.model_dump() for o in orders_db]
    output = json.dumps(data, indent=2)
    return StreamingResponse(
        io.BytesIO(output.encode()),
        media_type="application/json",
        headers={"Content-Disposition": "attachment; filename=loadnex_orders.json"}
    )

@router.post("/import/csv")
async def import_orders_csv(file: UploadFile = File(...)):
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Only CSV files are supported.")
    content = await file.read()
    decoded = content.decode('utf-8')
    reader = csv.DictReader(io.StringIO(decoded))
    imported_count = 0
    for row in reader:
        try:
            new_ord = OrderSchema(
                id=row["id"],
                customer_name=row["customer_name"],
                latitude=float(row["latitude"]),
                longitude=float(row["longitude"]),
                demand_weight=float(row["demand_weight"]),
                package_volume=float(row["package_volume"]),
                delivery_type=row.get("delivery_type", "drop"),
                time_window_start=row.get("time_window_start", "09:00"),
                time_window_end=row.get("time_window_end", "17:00"),
                service_time=int(row.get("service_time", 15)),
                priority=row.get("priority", "normal"),
                fragile=row.get("fragile", "false").lower() == "true",
                stackable=row.get("stackable", "true").lower() == "true",
                status="pending"
            )
            existing_idx = next((i for i, o in enumerate(orders_db) if o.id == new_ord.id), None)
            if existing_idx is not None:
                orders_db[existing_idx] = new_ord
            else:
                orders_db.append(new_ord)
            imported_count += 1
        except Exception:
            continue

    return {"message": f"Successfully imported {imported_count} orders into LoadNex AI."}
