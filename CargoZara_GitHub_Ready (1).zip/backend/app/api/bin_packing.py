from fastapi import APIRouter
from ..schemas.payload import BinPackingRequest, BinPackingResult
from ..optimization.bin3d_solver import Bin3DSolver

router = APIRouter(prefix="/optimize/bin-packing", tags=["3D Bin Packing"])

@router.post("", response_model=BinPackingResult)
def run_bin_packing(req: BinPackingRequest):
    solver = Bin3DSolver(
        container_length=req.container_length,
        container_width=req.container_width,
        container_height=req.container_height,
        max_weight=req.max_weight,
        vehicle_id=req.vehicle_id or "V01"
    )
    return solver.pack(req.packages)
