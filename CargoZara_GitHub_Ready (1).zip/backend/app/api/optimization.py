from fastapi import APIRouter
from typing import Dict, Any
from ..schemas.payload import VrptwRequest, VrptwResult
from ..optimization.vrptw_solver import VRPTWSolver
from ..optimization.integrated_solver import IntegratedSolver
from ..api.orders import orders_db
from ..api.vehicles import vehicles_db
from ..api.drivers import drivers_db
from ..seed_data import DEMO_DEPOT

router = APIRouter(prefix="/optimize", tags=["Optimization"])

@router.post("/vrptw", response_model=VrptwResult)
def run_vrptw_optimization(req: VrptwRequest):
    target_orders = req.orders if req.orders is not None else orders_db
    target_vehicles = req.vehicles if req.vehicles is not None else vehicles_db
    target_drivers = req.drivers if req.drivers is not None else drivers_db
    depot = req.depot or DEMO_DEPOT

    solver = VRPTWSolver(
        orders=target_orders,
        vehicles=target_vehicles,
        drivers=target_drivers,
        depot=depot,
        objective=req.objective
    )
    return solver.solve()

@router.post("/integrated")
def run_integrated_optimization(req: VrptwRequest):
    target_orders = req.orders if req.orders is not None else orders_db
    target_vehicles = req.vehicles if req.vehicles is not None else vehicles_db
    target_drivers = req.drivers if req.drivers is not None else drivers_db
    depot = req.depot or DEMO_DEPOT

    solver = IntegratedSolver(
        orders=target_orders,
        vehicles=target_vehicles,
        drivers=target_drivers,
        depot=depot,
        objective=req.objective
    )
    return solver.solve()
