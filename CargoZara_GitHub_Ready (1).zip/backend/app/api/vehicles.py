from fastapi import APIRouter, HTTPException
from typing import List
from ..schemas.payload import VehicleSchema
from ..seed_data import DEMO_VEHICLES

router = APIRouter(prefix="/vehicles", tags=["Vehicles"])

vehicles_db: List[VehicleSchema] = list(DEMO_VEHICLES)

@router.get("", response_model=List[VehicleSchema])
def get_vehicles():
    return vehicles_db

@router.post("", response_model=VehicleSchema)
def create_vehicle(vehicle: VehicleSchema):
    if any(v.id == vehicle.id for v in vehicles_db):
        raise HTTPException(status_code=400, detail=f"Vehicle {vehicle.id} already exists.")
    vehicles_db.append(vehicle)
    return vehicle

@router.put("/{vehicle_id}", response_model=VehicleSchema)
def update_vehicle(vehicle_id: str, updated_vehicle: VehicleSchema):
    for i, v in enumerate(vehicles_db):
        if v.id == vehicle_id:
            vehicles_db[i] = updated_vehicle
            return updated_vehicle
    raise HTTPException(status_code=404, detail="Vehicle not found")

@router.delete("/{vehicle_id}")
def delete_vehicle(vehicle_id: str):
    global vehicles_db
    vehicles_db = [v for v in vehicles_db if v.id != vehicle_id]
    return {"message": f"Vehicle {vehicle_id} deleted successfully."}
