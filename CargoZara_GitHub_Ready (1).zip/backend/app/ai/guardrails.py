from typing import List, Dict, Any, Tuple
import re

class AIGuardrails:
    @staticmethod
    def check_time_window_conflict(user_message: str, orders: List[Dict[str, Any]]) -> List[str]:
        """Detects contradictions between requested times in prompt and registered order time windows."""
        warnings = []
        msg_lower = user_message.lower()

        # Match phrases like "before 8 am", "at 08:00", "by 9:00"
        match = re.search(r'(before|by|at|around)\s*(\d{1,2})\s*(am|pm|:00)?', msg_lower)
        if match:
            time_num = int(match.group(2))
            period = match.group(3) if match.group(3) else ""
            if "pm" in period and time_num < 12:
                time_num += 12
            req_mins = time_num * 60

            # Check if any order is mentioned in prompt
            for order in orders:
                c_name = order.get("customer_name", "").lower()
                c_id = order.get("id", "").lower()
                if c_name in msg_lower or c_id in msg_lower:
                    tw_start_str = order.get("time_window_start", "09:00")
                    tw_end_str = order.get("time_window_end", "17:00")
                    try:
                        s_h, s_m = map(int, tw_start_str.split(":"))
                        e_h, e_m = map(int, tw_end_str.split(":"))
                        s_mins = s_h * 60 + s_m
                        e_mins = e_h * 60 + e_m

                        if req_mins < s_mins:
                            warnings.append(
                                f"Constraint conflict detected: Requested delivery for {order.get('customer_name')} "
                                f"({time_num}:00) is before registered window start ({tw_start_str})."
                            )
                        elif req_mins > e_mins:
                            warnings.append(
                                f"Constraint conflict detected: Requested delivery for {order.get('customer_name')} "
                                f"({time_num}:00) is after registered window end ({tw_end_str})."
                            )
                    except Exception:
                        pass
        return warnings

    @staticmethod
    def sanitize_structured_request(payload: Dict[str, Any]) -> Tuple[bool, List[str]]:
        warnings = []
        if "vehicles" in payload:
            for v in payload["vehicles"]:
                if v.get("max_weight_capacity", 0) <= 0:
                    warnings.append(f"Invalid vehicle capacity in AI intent for {v.get('id')}.")
        return len(warnings) == 0, warnings
