import os
import json
import re
from typing import Dict, Any, List
from .guardrails import AIGuardrails

class GeminiLogisticsAssistant:
    def __init__(self, api_key: str = ""):
        self.api_key = api_key or os.getenv("GEMINI_API_KEY", "")

    def process_message(self, message: str, orders: List[Dict[str, Any]], vehicles: List[Dict[str, Any]], drivers: List[Dict[str, Any]]) -> Dict[str, Any]:
        msg_lower = message.lower()
        guardrail_warnings = AIGuardrails.check_time_window_conflict(message, orders)

        intent = "query"
        function_called = None
        extracted_constraints = {}
        structured_output = None
        reply_lines = []

        # Intent Detection Logic
        if "unavailable" in msg_lower or "do not use" in msg_lower or "remove" in msg_lower or "what if" in msg_lower:
            intent = "scenario_simulation"
            function_called = "run_what_if"

            # Extract removed vehicle IDs if mentioned
            removed_vehs = []
            for v in vehicles:
                v_id = v.get("id", "").lower()
                v_type = v.get("vehicle_type", "").lower()
                if v_id in msg_lower or f"truck {v_id[-1]}" in msg_lower or f"vehicle {v_id[-1]}" in msg_lower:
                    removed_vehs.append(v.get("id"))

            extracted_constraints["removed_vehicle_ids"] = removed_vehs
            reply_lines.append(f"Analyzing scenario with vehicle exclusions: {removed_vehs if removed_vehs else 'None specified'}.")
            reply_lines.append("I have dispatched `run_what_if` tool to calculate the impact on route distance and costs.")

        elif "route" in msg_lower or "optimize" in msg_lower or "deliver" in msg_lower or "distance" in msg_lower:
            intent = "vrptw_optimization"
            function_called = "optimize_vrptw"

            obj = "minimize_distance"
            if "cost" in msg_lower:
                obj = "minimize_cost"
            elif "delay" in msg_lower or "time" in msg_lower:
                obj = "minimize_delay"

            extracted_constraints["objective"] = obj
            reply_lines.append(f"Identified VRPTW optimization intent with objective `{obj}`.")
            reply_lines.append(f"Executing `optimize_vrptw` solver over {len(orders)} active orders and {len(vehicles)} vehicles.")

        elif "loading" in msg_lower or "pack" in msg_lower or "3d" in msg_lower or "cargo" in msg_lower:
            intent = "3d_bin_packing"
            function_called = "optimize_bin_packing"
            reply_lines.append("Identified 3D Bin Packing request.")
            reply_lines.append("Executing `optimize_bin_packing` tool with 6-axis rotation and sequence accessibility rules.")

        else:
            intent = "general_query"
            reply_lines.append(f"LoadNex AI Status Report: Currently tracking {len(orders)} orders, {len(vehicles)} vehicles, and {len(drivers)} drivers.")
            reply_lines.append("You can ask me to re-optimize routes, simulate vehicle breakdowns, or generate 3D truck loading plans!")

        if guardrail_warnings:
            reply_lines.append("\n⚠️ **Guardrail Notice:**")
            for w in guardrail_warnings:
                reply_lines.append(f"- {w}")

        final_reply = "\n".join(reply_lines)

        return {
            "reply": final_reply,
            "intent_detected": intent,
            "function_called": function_called,
            "extracted_constraints": extracted_constraints,
            "guardrail_warnings": guardrail_warnings,
            "structured_output": {
                "request_type": intent,
                "target_orders": len(orders),
                "target_vehicles": len(vehicles),
                "executed_tool": function_called
            }
        }
