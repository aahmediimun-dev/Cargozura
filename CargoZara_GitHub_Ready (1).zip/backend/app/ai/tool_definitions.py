from typing import List, Dict, Any

TOOL_DEFINITIONS = [
    {
        "name": "optimize_vrptw",
        "description": "Execute VRPTW routing solver with specified parameters and objective.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "objective": {"type": "STRING", "description": "minimize_distance, minimize_cost, minimize_delay, minimize_vehicles"},
                "vehicle_ids": {"type": "ARRAY", "items": {"type": "STRING"}},
                "allow_overtime": {"type": "BOOLEAN"}
            }
        }
    },
    {
        "name": "optimize_bin_packing",
        "description": "Execute 3D Bin Packing solver for a vehicle container.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "vehicle_id": {"type": "STRING"},
                "container_length": {"type": "NUMBER"},
                "container_width": {"type": "NUMBER"},
                "container_height": {"type": "NUMBER"},
                "max_weight": {"type": "NUMBER"}
            }
        }
    },
    {
        "name": "run_what_if",
        "description": "Simulate what-if scenario by modifying fleet, orders, or demand multiplier.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "scenario_name": {"type": "STRING"},
                "demand_multiplier": {"type": "NUMBER"},
                "removed_vehicle_ids": {"type": "ARRAY", "items": {"type": "STRING"}},
                "removed_order_ids": {"type": "ARRAY", "items": {"type": "STRING"}}
            }
        }
    },
    {
        "name": "get_orders",
        "description": "Retrieve current pending and active orders list.",
        "parameters": {"type": "OBJECT", "properties": {}}
    },
    {
        "name": "get_vehicles",
        "description": "Retrieve vehicle fleet status and capacities.",
        "parameters": {"type": "OBJECT", "properties": {}}
    },
    {
        "name": "get_drivers",
        "description": "Retrieve driver roster and availability.",
        "parameters": {"type": "OBJECT", "properties": {}}
    }
]
