import os
from pathlib import Path
from pydantic import BaseModel

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseModel):
    PROJECT_NAME: str = "LogiOpt"
    TAGLINE: str = "Intelligent Routing & 3D Cargo Optimization System"
    API_V1_STR: str = "/api"
    DATABASE_URL: str = os.getenv("DATABASE_URL", f"sqlite:///{BASE_DIR.as_posix()}/loadnex.db")
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    DEFAULT_SPEED_KMH: float = 40.0
    DEFAULT_COST_PER_KM: float = 35.0

settings = Settings()
