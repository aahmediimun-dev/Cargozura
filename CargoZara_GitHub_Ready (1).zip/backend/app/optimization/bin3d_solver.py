from typing import List, Dict, Any, Tuple, Optional
from ..schemas.payload import PackageSchema, BinPackingResult, PlacedItem

COLOR_PALETTE = [
    "#3B82F6", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6",
    "#EC4899", "#14B8A6", "#F97316", "#6366F1", "#84CC16"
]

class Bin3DSolver:
    def __init__(self, container_length: float, container_width: float, container_height: float, max_weight: float, vehicle_id: str = "V01"):
        self.cl = container_length
        self.cw = container_width
        self.ch = container_height
        self.max_weight = max_weight
        self.vehicle_id = vehicle_id

    def _get_rotations(self, length: float, width: float, height: float, stackable: bool) -> List[Tuple[float, float, float]]:
        """Returns valid (dx, dy, dz) orientations. If not stackable, height cannot be rotated to base."""
        if not stackable:
            return [
                (length, width, height),
                (width, length, height)
            ]
        return [
            (length, width, height),
            (length, height, width),
            (width, length, height),
            (width, height, length),
            (height, length, width),
            (height, width, length)
        ]

    def _is_overlapping(self, box1: Tuple[float, float, float, float, float, float], box2: Tuple[float, float, float, float, float, float]) -> bool:
        """Checks 3D bounding box overlap: box = (x, y, z, dx, dy, dz)."""
        x1, y1, z1, dx1, dy1, dz1 = box1
        x2, y2, z2, dx2, dy2, dz2 = box2

        return not (
            x1 + dx1 <= x2 or x2 + dx2 <= x1 or
            y1 + dy1 <= y2 or y2 + dy2 <= y1 or
            z1 + dz1 <= z2 or z2 + dz2 <= z1
        )

    def pack(self, packages: List[PackageSchema]) -> BinPackingResult:
        container_volume = self.cl * self.cw * self.ch

        # Sort packages by delivery_stop descending (LIFO - last stop loaded first, earliest stop loaded near doors)
        # and then by volume descending
        sorted_packages = sorted(
            packages,
            key=lambda p: (p.delivery_stop, -(p.length * p.width * p.height)),
            reverse=True
        )

        placed_items: List[PlacedItem] = []
        placed_boxes: List[Tuple[float, float, float, float, float, float]] = []
        unloaded_items: List[PackageSchema] = []

        current_weight = 0.0
        current_volume = 0.0
        stability_warnings = []
        collision_warnings = []

        # Candidate pivot placement points: start at origin (0, 0, 0)
        candidate_points = [(0.0, 0.0, 0.0)]

        for pkg in sorted_packages:
            pkg_vol = pkg.length * pkg.width * pkg.height

            if current_weight + pkg.weight > self.max_weight:
                unloaded_items.append(pkg)
                continue

            placed = False

            # Sort candidate points by z (bottom-up), then y, then x
            candidate_points.sort(key=lambda pt: (pt[2], pt[1], pt[0]))

            for pt in list(candidate_points):
                px, py, pz = pt

                orientations = self._get_rotations(pkg.length, pkg.width, pkg.height, pkg.stackable)

                for dx, dy, dz in orientations:
                    # Container boundary check
                    if px + dx > self.cl + 0.001 or py + dy > self.cw + 0.001 or pz + dz > self.ch + 0.001:
                        continue

                    candidate_box = (px, py, pz, dx, dy, dz)

                    # Collision check
                    overlap = False
                    for b in placed_boxes:
                        if self._is_overlapping(candidate_box, b):
                            overlap = True
                            break

                    if overlap:
                        continue

                    # If above ground (pz > 0), simple floor support check
                    if pz > 0.001:
                        has_support = False
                        for bx, by, bz, bdx, bdy, bdz in placed_boxes:
                            if abs((bz + bdz) - pz) < 0.01:
                                # Overlap in XY plane
                                if not (px + dx <= bx or bx + bdx <= px or py + dy <= by or by + bdy <= py):
                                    has_support = True
                                    break
                        if not has_support:
                            stability_warnings.append(f"Package {pkg.id} at z={pz}m has partial base support.")

                    # Place package
                    color = COLOR_PALETTE[len(placed_items) % len(COLOR_PALETTE)]
                    placed_item = PlacedItem(
                        id=pkg.id,
                        order_id=pkg.order_id,
                        length=round(dx, 2),
                        width=round(dy, 2),
                        height=round(dz, 2),
                        weight=round(pkg.weight, 1),
                        position=[round(px, 2), round(py, 2), round(pz, 2)],
                        rotation=[0.0, 90.0 if (dx != pkg.length or dy != pkg.width) else 0.0, 0.0],
                        delivery_stop=pkg.delivery_stop,
                        color=color
                    )

                    placed_items.append(placed_item)
                    placed_boxes.append(candidate_box)
                    current_weight += pkg.weight
                    current_volume += pkg_vol
                    placed = True

                    # Generate new candidate pivot points
                    candidate_points.append((px + dx, py, pz))
                    candidate_points.append((px, py + dy, pz))
                    candidate_points.append((px, py, pz + dz))

                    break  # orientation found

                if placed:
                    break

            if not placed:
                unloaded_items.append(pkg)

        vol_util = round((current_volume / max(container_volume, 0.001)) * 100.0, 1)
        wt_util = round((current_weight / max(self.max_weight, 0.001)) * 100.0, 1)
        unused_vol = round(max(0.0, container_volume - current_volume), 2)
        loading_efficiency = round((len(placed_items) / max(len(packages), 1)) * 100.0, 1)

        return BinPackingResult(
            vehicle_id=self.vehicle_id,
            container_dimensions={
                "length": self.cl,
                "width": self.cw,
                "height": self.ch,
                "max_weight": self.max_weight
            },
            volume_utilization=vol_util,
            weight_utilization=wt_util,
            packages_loaded=len(placed_items),
            packages_unloaded=len(unloaded_items),
            unused_volume=unused_vol,
            loading_efficiency=loading_efficiency,
            items=placed_items,
            unloaded_items=unloaded_items,
            stability_warnings=list(set(stability_warnings)),
            collision_warnings=collision_warnings
        )
