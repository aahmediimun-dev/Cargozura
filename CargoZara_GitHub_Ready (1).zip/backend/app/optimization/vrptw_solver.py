import math
from typing import List, Dict, Any, Tuple
from ..schemas.payload import OrderSchema, VehicleSchema, DriverSchema, DepotSchema, VrptwResult, VehicleRoute, RouteStop

def parse_time(time_str: str) -> float:
    """Converts HH:MM string into minutes from 00:00."""
    try:
        parts = time_str.split(":")
        return float(int(parts[0]) * 60 + int(parts[1]))
    except Exception:
        return 540.0  # default 09:00

def format_time(minutes: float) -> str:
    """Converts minutes from midnight back to HH:MM format."""
    mins = int(round(minutes)) % (24 * 60)
    hrs = mins // 60
    m = mins % 60
    return f"{hrs:02d}:{m:02d}"

def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculates Haversine distance in km between two lat/lon coordinates."""
    R = 6371.0  # Earth radius in km
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * (math.sin(dlon / 2) ** 2))
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return round(R * c, 2)

class VRPTWSolver:
    def __init__(self, orders: List[OrderSchema], vehicles: List[VehicleSchema], drivers: List[DriverSchema], depot: DepotSchema, objective: str = "minimize_distance"):
        self.orders = [o for o in orders if o.status != "cancelled"]
        self.vehicles = [v for v in vehicles if v.availability and v.status != "maintenance"]
        self.drivers = [d for d in drivers if d.availability and d.status != "off_duty"]
        self.depot = depot
        self.objective = objective
        self.speed_kmh = 40.0

    def solve(self) -> VrptwResult:
        if not self.orders:
            return VrptwResult(
                status="feasible",
                objective=self.objective,
                vehicles_used=0,
                routes=[],
                total_distance=0.0,
                total_cost=0.0,
                total_travel_time=0.0,
                on_time_rate=100.0,
                weight_utilization=0.0,
                volume_utilization=0.0,
                late_deliveries=0,
                constraint_violations=[],
                message="No active orders to route."
            )

        if not self.vehicles:
            return VrptwResult(
                status="infeasible",
                objective=self.objective,
                vehicles_used=0,
                routes=[],
                total_distance=0.0,
                total_cost=0.0,
                total_travel_time=0.0,
                on_time_rate=0.0,
                weight_utilization=0.0,
                volume_utilization=0.0,
                late_deliveries=len(self.orders),
                constraint_violations=["No available vehicles to perform routes."],
                message="Optimization failed: No available vehicles."
            )

        # Sort orders according to objective & time window start
        sorted_orders = sorted(self.orders, key=lambda o: (
            0 if o.priority == "urgent" else (1 if o.priority == "high" else 2),
            parse_time(o.time_window_start)
        ))

        # Assign drivers to vehicles
        vehicle_driver_map = {}
        available_drivers = list(self.drivers)
        for i, veh in enumerate(self.vehicles):
            if veh.driver_assigned:
                vehicle_driver_map[veh.id] = veh.driver_assigned
            elif available_drivers:
                drv = available_drivers.pop(0)
                vehicle_driver_map[veh.id] = drv.id
            else:
                vehicle_driver_map[veh.id] = "Unassigned"

        routes: List[VehicleRoute] = []
        unassigned_orders = list(sorted_orders)
        violations = []

        depot_start_min = parse_time(self.depot.time_window_start)

        for veh in self.vehicles:
            if not unassigned_orders:
                break

            current_lat = self.depot.latitude
            current_lon = self.depot.longitude
            current_time = depot_start_min
            current_weight = 0.0
            current_volume = 0.0
            route_stops: List[RouteStop] = []
            assigned_this_veh = []

            for order in list(unassigned_orders):
                # Capacity checks
                if (current_weight + order.demand_weight > veh.max_weight_capacity or
                    current_volume + order.package_volume > veh.volume_capacity):
                    continue

                # Distance & Travel time calculation
                dist = calculate_distance(current_lat, current_lon, order.latitude, order.longitude)
                travel_time_min = (dist / self.speed_kmh) * 60.0

                arrival_time = current_time + travel_time_min
                tw_start = parse_time(order.time_window_start)
                tw_end = parse_time(order.time_window_end)

                # Wait if arriving before time window
                service_start = max(arrival_time, tw_start)

                # Late check
                late_mins = max(0.0, service_start - tw_end)

                departure_time = service_start + order.service_time

                # Check total driver work hours (max 8-10 hours)
                if (departure_time - depot_start_min) > (10 * 60):
                    continue

                # Add stop
                current_weight += order.demand_weight
                current_volume += order.package_volume
                current_lat = order.latitude
                current_lon = order.longitude
                current_time = departure_time

                route_stop = RouteStop(
                    sequence=len(route_stops) + 1,
                    order_id=order.id,
                    customer_name=order.customer_name,
                    arrival_time=format_time(arrival_time),
                    departure_time=format_time(departure_time),
                    distance_from_prev=dist,
                    travel_time_min=round(travel_time_min, 1),
                    load_weight=round(current_weight, 1),
                    load_volume=round(current_volume, 2),
                    delivery_type=order.delivery_type,
                    late_minutes=round(late_mins, 1)
                )

                route_stops.append(route_stop)
                assigned_this_veh.append(order)
                unassigned_orders.remove(order)

            if route_stops:
                # Return to depot distance
                return_dist = calculate_distance(current_lat, current_lon, self.depot.latitude, self.depot.longitude)
                total_dist = sum(s.distance_from_prev for s in route_stops) + return_dist
                total_travel = sum(s.travel_time_min for s in route_stops) + (return_dist / self.speed_kmh * 60.0)

                weight_util = round((current_weight / veh.max_weight_capacity) * 100, 1)
                volume_util = round((current_volume / veh.volume_capacity) * 100, 1)
                cost = round(total_dist * veh.cost_per_km, 2)
                late_count = sum(1 for s in route_stops if s.late_minutes > 0)

                v_route = VehicleRoute(
                    vehicle_id=veh.id,
                    driver_id=vehicle_driver_map.get(veh.id, "Unassigned"),
                    stops=route_stops,
                    total_distance=round(total_dist, 2),
                    total_travel_time=round(total_travel, 1),
                    total_weight=round(current_weight, 1),
                    total_volume=round(current_volume, 2),
                    weight_utilization=weight_util,
                    volume_utilization=volume_util,
                    cost=cost,
                    status="feasible" if late_count == 0 else "late_risk",
                    late_deliveries=late_count
                )
                routes.append(v_route)

        if unassigned_orders:
            violations.append(f"{len(unassigned_orders)} orders could not be assigned due to vehicle capacity or time window limits.")

        total_distance = sum(r.total_distance for r in routes)
        total_cost = sum(r.cost for r in routes)
        total_travel_time = sum(r.total_travel_time for r in routes)
        total_stops = sum(len(r.stops) for r in routes)
        total_late = sum(r.late_deliveries for r in routes)

        on_time_rate = round(((total_stops - total_late) / max(total_stops, 1)) * 100.0, 1)

        avg_weight_util = round(sum(r.weight_utilization for r in routes) / max(len(routes), 1), 1)
        avg_volume_util = round(sum(r.volume_utilization for r in routes) / max(len(routes), 1), 1)

        status_str = "heuristic_solution" if len(routes) > 0 else "infeasible"
        if violations:
            msg = f"Generated heuristic route solution with {len(routes)} vehicles. Note: {len(unassigned_orders)} orders unassigned."
        else:
            msg = f"Successfully generated feasible VRPTW heuristic route plan for {len(self.orders)} orders across {len(routes)} vehicles."

        return VrptwResult(
            status=status_str,
            objective=self.objective,
            vehicles_used=len(routes),
            routes=routes,
            total_distance=round(total_distance, 2),
            total_cost=round(total_cost, 2),
            total_travel_time=round(total_travel_time, 1),
            on_time_rate=on_time_rate,
            weight_utilization=avg_weight_util,
            volume_utilization=avg_volume_util,
            late_deliveries=total_late,
            constraint_violations=violations,
            message=msg
        )
