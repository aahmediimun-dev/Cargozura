from typing import List, Dict, Any, Tuple
from ..schemas.payload import OrderSchema, VehicleSchema, DriverSchema

class ProblemValidator:
    @staticmethod
    def validate_orders(orders: List[OrderSchema]) -> Tuple[bool, List[str]]:
        errors = []
        for o in orders:
            if o.demand_weight <= 0:
                errors.append(f"Order {o.id}: Demand weight must be positive.")
            if o.package_volume <= 0:
                errors.append(f"Order {o.id}: Package volume must be positive.")
            if not (-90 <= o.latitude <= 90):
                errors.append(f"Order {o.id}: Invalid latitude {o.latitude}.")
            if not (-180 <= o.longitude <= 180):
                errors.append(f"Order {o.id}: Invalid longitude {o.longitude}.")
            try:
                s_parts = [int(x) for x in o.time_window_start.split(":")]
                e_parts = [int(x) for x in o.time_window_end.split(":")]
                s_mins = s_parts[0] * 60 + s_parts[1]
                e_mins = e_parts[0] * 60 + e_parts[1]
                if s_mins >= e_mins:
                    errors.append(f"Order {o.id}: Time window start ({o.time_window_start}) must be before end ({o.time_window_end}).")
            except Exception:
                errors.append(f"Order {o.id}: Time window format must be HH:MM.")
        return len(errors) == 0, errors

    @staticmethod
    def validate_vehicles(vehicles: List[VehicleSchema]) -> Tuple[bool, List[str]]:
        errors = []
        for v in vehicles:
            if v.max_weight_capacity <= 0:
                errors.append(f"Vehicle {v.id}: Max weight capacity must be positive.")
            if v.length <= 0 or v.width <= 0 or v.height <= 0:
                errors.append(f"Vehicle {v.id}: Dimensions must be positive.")
        return len(errors) == 0, errors
