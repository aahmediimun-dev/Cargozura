from typing import List, Dict, Any
from ..schemas.payload import (
    OrderSchema, VehicleSchema, DriverSchema, DepotSchema,
    VrptwResult, BinPackingResult, PackageSchema
)
from .vrptw_solver import VRPTWSolver
from .bin3d_solver import Bin3DSolver

class IntegratedSolver:
    def __init__(self, orders: List[OrderSchema], vehicles: List[VehicleSchema], drivers: List[DriverSchema], depot: DepotSchema, objective: str = "minimize_distance"):
        self.orders = orders
        self.vehicles = vehicles
        self.drivers = drivers
        self.depot = depot
        self.objective = objective

    def solve(self) -> Dict[str, Any]:
        # Step 1: Run VRPTW Solver
        vrptw_solver = VRPTWSolver(self.orders, self.vehicles, self.drivers, self.depot, self.objective)
        vrptw_result: VrptwResult = vrptw_solver.solve()

        # Step 2: Generate 3D Bin Packing per vehicle route
        vehicle_map = {v.id: v for v in self.vehicles}
        loading_plans: Dict[str, Any] = {}

        for route in vrptw_result.routes:
            veh = vehicle_map.get(route.vehicle_id)
            if not veh:
                continue

            # Gather packages for orders in this route
            route_packages: List[PackageSchema] = []
            for stop in route.stops:
                # Find matching order
                order = next((o for o in self.orders if o.id == stop.order_id), None)
                if not order:
                    continue

                # Estimate package dimensions based on order volume & weight
                # Example: calculate cubical dimensions or standard box shapes
                vol = max(order.package_volume, 0.05)
                side = round(vol ** (1/3), 2)
                l = round(min(side * 1.2, veh.length * 0.4), 2)
                w = round(min(side, veh.width * 0.4), 2)
                h = round(min(side * 0.8, veh.height * 0.4), 2)

                pkg = PackageSchema(
                    id=f"PKG-{order.id}",
                    order_id=order.id,
                    length=max(l, 0.3),
                    width=max(w, 0.3),
                    height=max(h, 0.3),
                    weight=order.demand_weight,
                    fragile=order.fragile,
                    stackable=order.stackable,
                    priority=order.priority,
                    delivery_stop=stop.sequence
                )
                route_packages.append(pkg)

            # Solve 3D Bin Packing for this vehicle
            bin_solver = Bin3DSolver(
                container_length=veh.length,
                container_width=veh.width,
                container_height=veh.height,
                max_weight=veh.max_weight_capacity,
                vehicle_id=veh.id
            )
            packing_result: BinPackingResult = bin_solver.pack(route_packages)
            loading_plans[veh.id] = packing_result.model_dump()

        return {
            "status": vrptw_result.status,
            "vrptw_result": vrptw_result.model_dump(),
            "loading_plans": loading_plans
        }
